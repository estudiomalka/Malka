<?php
/**
 * Bienestar: hábitos y medidas del cuerpo.
 *
 * Dos cosas distintas que comparten pantalla:
 *
 * 1. Hábitos. Algo que se quiere hacer seguido. Se marca el día que se
 *    hizo y se ve la racha. No hay castigo por cortarla: cortar una racha
 *    es normal y una pantalla que lo retara serviría para abandonarla.
 *
 * 2. Medidas del cuerpo. Un registro con fecha y su línea en el tiempo.
 *    A propósito NO tiene metas, ni rangos «buenos» y «malos», ni le pone
 *    nombre a ningún número. Es un cuaderno: anota lo que ella mide y le
 *    muestra cómo viene. Qué significa eso lo dice quien corresponde, que
 *    no es un plugin.
 *
 * Antes esta sección decía «fechas y recordatorios, nunca resultados».
 * Cambió porque ella pidió llevar sus medidas acá; lo que no cambió es
 * que el panel no opina sobre ellas.
 *
 * @package Malka_CRM
 */

defined( 'ABSPATH' ) || exit;

class Malka_CRM_Bienestar {

	/** Dónde se guarda todo. */
	const OPCION = 'malka_crm_bienestar';

	/** Cuántos registros de medidas se conservan. */
	const TOPE = 1000;

	public static function init() {
		add_action( 'admin_post_malka_crm_habito_nuevo', array( __CLASS__, 'handle_habito_nuevo' ) );
		add_action( 'admin_post_malka_crm_habito_borrar', array( __CLASS__, 'handle_habito_borrar' ) );
		add_action( 'admin_post_malka_crm_medida_anotar', array( __CLASS__, 'handle_medida_anotar' ) );
		add_action( 'admin_post_malka_crm_medida_borrar', array( __CLASS__, 'handle_medida_borrar' ) );
		add_action( 'admin_post_malka_crm_medida_tipo', array( __CLASS__, 'handle_medida_tipo' ) );
		add_action( 'admin_post_malka_crm_medida_meta', array( __CLASS__, 'handle_medida_meta' ) );
		add_action( 'admin_post_malka_crm_medida_punto', array( __CLASS__, 'handle_medida_punto' ) );
		add_action( 'admin_post_malka_crm_silueta', array( __CLASS__, 'handle_silueta' ) );
		add_action( 'admin_post_malka_crm_medida_editar', array( __CLASS__, 'handle_medida_editar' ) );
		add_action( 'wp_ajax_malka_crm_habito_marcar', array( __CLASS__, 'ajax_marcar' ) );
	}

	/**
	 * Todo lo guardado.
	 *
	 * @return array habitos, hechos, tipos, medidas.
	 */
	public static function datos() {
		$d = get_option( self::OPCION, array() );

		if ( ! is_array( $d ) ) {
			$d = array();
		}

		return array(
			'habitos' => isset( $d['habitos'] ) && is_array( $d['habitos'] ) ? $d['habitos'] : array(),
			// hechos[ id del hábito ][ Y-m-d ] = true
			'hechos'  => isset( $d['hechos'] ) && is_array( $d['hechos'] ) ? $d['hechos'] : array(),
			'tipos'   => isset( $d['tipos'] ) && is_array( $d['tipos'] ) ? $d['tipos'] : self::tipos_de_fabrica(),
			'medidas' => isset( $d['medidas'] ) && is_array( $d['medidas'] ) ? $d['medidas'] : array(),
			// Qué silueta se dibuja. Es sólo el dibujo de referencia:
			// no cambia nada de lo que se mide ni de lo guardado.
			'silueta' => isset( $d['silueta'] ) && 'm' === $d['silueta'] ? 'm' : 'f',
		);
	}

	private static function guardar_todo( $d ) {
		update_option( self::OPCION, $d, false );
	}

	/**
	 * Con qué se arranca, para no empezar con la pantalla en blanco.
	 *
	 * @return array[]
	 */
	public static function tipos_de_fabrica() {
		return array(
			array( 'clave' => 'peso', 'nombre' => 'Peso', 'unidad' => 'kg', 'dec' => 1 ),
			array( 'clave' => 'grasa', 'nombre' => 'Grasa', 'unidad' => '%', 'dec' => 1 ),
		);
	}

	/* ──────────────────────────────  Hábitos  ─────────────────────────── */

	/**
	 * Los hábitos, con su racha y si hoy está marcado.
	 *
	 * @return array[]
	 */
	public static function habitos( $dia = '' ) {
		$d   = self::datos();
		$hoy = current_time( 'Y-m-d' );

		/*
		 * Se puede mirar un día de atrás, para marcar lo que se olvidó y
		 * para desmarcar lo que se marcó mal. Hacia adelante no: un hábito
		 * que todavía no pasó no se puede haber hecho.
		 */
		$dia = self::dia_valido( $dia );
		$out = array();

		foreach ( $d['habitos'] as $h ) {
			$id     = (int) $h['id'];
			$hechos = isset( $d['hechos'][ $id ] ) ? $d['hechos'][ $id ] : array();

			$out[] = array(
				'id'     => $id,
				'nombre' => $h['nombre'],
				'hoy'    => ! empty( $hechos[ $dia ] ),
				// La racha siempre se cuenta hasta hoy, se esté mirando el
				// día que se esté: es cuántos días seguidos lleva, no
				// cuántos llevaba el martes.
				'racha'  => self::racha( $hechos, $hoy ),
				'mes'    => self::ultimos_dias( $hechos, 28, $hoy ),
				'total'  => count( $hechos ),
			);
		}

		return $out;
	}

	/**
	 * El día que se está mirando, acotado a lo que tiene sentido.
	 *
	 * Ni el futuro —no se puede haber hecho algo que no ha pasado— ni más
	 * de un año atrás, que ya no es corregir un olvido sino inventar
	 * historia.
	 *
	 * @param string $dia Y-m-d, o vacío para hoy.
	 * @return string Y-m-d.
	 */
	public static function dia_valido( $dia ) {
		$hoy = current_time( 'Y-m-d' );
		$dia = trim( (string) $dia );

		if ( '' === $dia || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dia ) ) {
			return $hoy;
		}

		$tope = gmdate( 'Y-m-d', strtotime( $hoy . ' -1 year' ) );

		if ( $dia > $hoy ) {
			return $hoy;
		}

		if ( $dia < $tope ) {
			return $tope;
		}

		return $dia;
	}

	/**
	 * Cuántos días seguidos viene marcado, contando hasta hoy.
	 *
	 * Si hoy todavía no está marcado, la racha no se corta: el día no ha
	 * terminado. Se cuenta desde ayer. Cortar una racha porque son las
	 * diez de la mañana sería mentir sobre lo que pasó.
	 *
	 * @param array  $hechos Y-m-d => true.
	 * @param string $hoy    Y-m-d.
	 * @return int
	 */
	public static function racha( $hechos, $hoy ) {
		$n    = 0;
		$dia  = $hoy;

		if ( empty( $hechos[ $hoy ] ) ) {
			$dia = gmdate( 'Y-m-d', strtotime( $hoy . ' -1 day' ) );
		}

		while ( ! empty( $hechos[ $dia ] ) ) {
			$n++;
			$dia = gmdate( 'Y-m-d', strtotime( $dia . ' -1 day' ) );
		}

		return $n;
	}

	/**
	 * Los últimos días, para el cuadrito.
	 *
	 * @param array  $hechos Y-m-d => true.
	 * @param int    $dias   Cuántos.
	 * @param string $hoy    Y-m-d.
	 * @return array[] fecha, hecho.
	 */
	public static function ultimos_dias( $hechos, $dias, $hoy ) {
		$out = array();

		for ( $i = $dias - 1; $i >= 0; $i-- ) {
			$f     = gmdate( 'Y-m-d', strtotime( $hoy . ' -' . $i . ' day' ) );
			$out[] = array(
				'fecha' => $f,
				'hecho' => ! empty( $hechos[ $f ] ),
			);
		}

		return $out;
	}

	/**
	 * Anota un hábito nuevo.
	 *
	 * @param string $nombre Cómo se llama.
	 * @return int id, o 0.
	 */
	public static function habito_nuevo( $nombre ) {
		$nombre = trim( sanitize_text_field( (string) $nombre ) );

		if ( '' === $nombre ) {
			return 0;
		}

		$d  = self::datos();
		$id = 1;

		foreach ( $d['habitos'] as $h ) {
			if ( (int) $h['id'] >= $id ) {
				$id = (int) $h['id'] + 1;
			}
		}

		$d['habitos'][] = array(
			'id'     => $id,
			'nombre' => $nombre,
		);

		self::guardar_todo( $d );

		return $id;
	}

	/**
	 * Borra un hábito y lo que llevaba marcado.
	 *
	 * @param int $id Id.
	 * @return bool
	 */
	public static function habito_borrar( $id ) {
		$id = (int) $id;
		$d  = self::datos();

		foreach ( $d['habitos'] as $i => $h ) {
			if ( (int) $h['id'] === $id ) {
				unset( $d['habitos'][ $i ] );
				$d['habitos'] = array_values( $d['habitos'] );
				unset( $d['hechos'][ $id ] );
				self::guardar_todo( $d );
				return true;
			}
		}

		return false;
	}

	/**
	 * Marca o desmarca un hábito en un día.
	 *
	 * @param int    $id    Hábito.
	 * @param string $fecha Y-m-d. Vacío: hoy.
	 * @param bool   $si    Marcar o desmarcar.
	 * @return bool Si existe el hábito.
	 */
	public static function marcar( $id, $fecha = '', $si = true ) {
		$id    = (int) $id;
		$d     = self::datos();
		$fecha = Malka_CRM_Helpers::sanitize_date( $fecha );

		if ( '' === $fecha ) {
			$fecha = current_time( 'Y-m-d' );
		}

		// Hacia adelante no: un hábito de mañana no se hizo todavía.
		if ( $fecha > current_time( 'Y-m-d' ) ) {
			return false;
		}

		$existe = false;

		foreach ( $d['habitos'] as $h ) {
			if ( (int) $h['id'] === $id ) {
				$existe = true;
			}
		}

		if ( ! $existe ) {
			return false;
		}

		if ( $si ) {
			$d['hechos'][ $id ][ $fecha ] = true;
		} else {
			unset( $d['hechos'][ $id ][ $fecha ] );
		}

		self::guardar_todo( $d );

		return true;
	}

	/* ──────────────────────────────  Medidas  ─────────────────────────── */

	/**
	 * Qué se está midiendo.
	 *
	 * @return array[]
	 */
	public static function tipos() {
		$d = self::datos();

		return $d['tipos'];
	}

	/**
	 * Un número escrito como se escribe en Chile.
	 *
	 * Antes acá sólo se cambiaba la coma por punto, y eso dejaba intacto
	 * el punto de los miles: ella anotó un metabolismo basal de 1.139
	 * kcal/d y quedó guardado 1,1. Cualquier medida sobre 999 se dividía
	 * por mil sin avisar, y el número equivocado se veía tan normal como
	 * uno bueno.
	 *
	 * Las reglas, en orden:
	 *  - Con coma y punto manda el último; el otro era de miles.
	 *  - Sólo comas: la coma es decimal; varias comas son de miles.
	 *  - Sólo puntos: un punto seguido de exactamente tres dígitos, con
	 *    algo delante, es de miles («1.139» son 1139). Con cualquier otra
	 *    cantidad de dígitos es decimal («1.5», «27.0», «12.50»).
	 *
	 * @param mixed $v Lo que se escribió.
	 * @return string Listo para is_numeric() y (float).
	 */
	public static function numero_medida( $v ) {
		$crudo = trim( (string) $v );

		/*
		 * El signo se guarda y se devuelve: una medida negativa no existe,
		 * pero quien la rechaza es quien llama. Si acá se borrara el guión,
		 * un «-5» mal tecleado entraría como 5 y nadie se daría cuenta.
		 */
		$negativo = 0 === strpos( $crudo, '-' );
		$t        = preg_replace( '/[^0-9.,]/', '', $crudo );

		if ( '' === $t ) {
			return '';
		}

		$coma  = strrpos( $t, ',' );
		$punto = strrpos( $t, '.' );

		if ( false !== $coma && false !== $punto ) {
			if ( $coma > $punto ) {
				$t = str_replace( ',', '.', str_replace( '.', '', $t ) );
			} else {
				$t = str_replace( ',', '', $t );
			}
		} elseif ( false !== $coma ) {
			$t = substr_count( $t, ',' ) > 1
				? str_replace( ',', '', $t )
				: str_replace( ',', '.', $t );
		} elseif ( false !== $punto ) {
			$miles = substr_count( $t, '.' ) > 1 || preg_match( '/^\d+\.\d{3}$/', $t );

			if ( $miles ) {
				$t = str_replace( '.', '', $t );
			}
		}

		return $negativo ? '-' . $t : $t;
	}

	/**
	 * Pone —o saca— la meta de una medida.
	 *
	 * La pone ella, no el panel. Esa es toda la diferencia: un número que
	 * una elige es una decisión suya, y uno que aparece solo en la
	 * pantalla es alguien opinando sobre su cuerpo sin que se lo pidan.
	 *
	 * Por eso la meta se dibuja como una raya de referencia y se dice la
	 * distancia, y nada más: no hay barra de progreso, ni porcentaje
	 * cumplido, ni felicitaciones, ni avisos de que va quedando lejos.
	 *
	 * @param string $clave Cuál.
	 * @param string $valor El número. Vacío: saca la meta.
	 * @return bool Si existe esa medida.
	 */
	public static function meta( $clave, $valor ) {
		$clave = sanitize_key( $clave );
		$valor = self::numero_medida( $valor );
		$d     = self::datos();
		$hubo  = false;

		foreach ( $d['tipos'] as $i => $t ) {
			if ( $t['clave'] !== $clave ) {
				continue;
			}

			$hubo = true;

			if ( '' === $valor || ! is_numeric( $valor ) || (float) $valor <= 0 ) {
				// Sacar la meta tiene que ser tan fácil como ponerla.
				unset( $d['tipos'][ $i ]['meta'] );
			} else {
				$d['tipos'][ $i ]['meta'] = round( (float) $valor, 2 );
			}
		}

		if ( $hubo ) {
			$d['tipos'] = array_values( $d['tipos'] );
			self::guardar_todo( $d );
		}

		return $hubo;
	}

	/**
	 * Agrega algo que medir.
	 *
	 * @param string $nombre Cómo se llama.
	 * @param string $unidad kg, %, cm…
	 * @return string La clave, o '' si no se pudo.
	 */
	public static function tipo_nuevo( $nombre, $unidad = '', $clave = '' ) {
		$nombre = trim( sanitize_text_field( (string) $nombre ) );

		if ( '' === $nombre ) {
			return '';
		}

		/*
		 * La clave viene dada cuando la medida sale del catálogo, y se
		 * deduce del nombre sólo cuando ella la inventa. Deduciéndola
		 * siempre, «Agua en el cuerpo» quedaba como «aguaenelcuerpo» y
		 * no coincidía con la del catálogo: el dibujo nunca la daba por
		 * puesta y lo anotado quedaba bajo otra clave.
		 */
		$clave = '' !== $clave
			? sanitize_key( $clave )
			: sanitize_key( remove_accents( $nombre ) );

		if ( '' === $clave ) {
			return '';
		}

		$d = self::datos();

		foreach ( $d['tipos'] as $t ) {
			if ( $t['clave'] === $clave ) {
				return $clave;
			}
		}

		$d['tipos'][] = array(
			'clave'  => $clave,
			'nombre' => $nombre,
			'unidad' => trim( sanitize_text_field( (string) $unidad ) ),
			'dec'    => 1,
		);

		self::guardar_todo( $d );

		return $clave;
	}

	/**
	 * Anota una medición.
	 *
	 * Los valores vacíos no se guardan: anotar sólo el peso un día y el
	 * peso y la grasa en otro es lo normal, y un cero por «no medí» haría
	 * que la línea se desplomara.
	 *
	 * @param array  $valores clave => número.
	 * @param string $fecha   Y-m-d. Vacío: hoy.
	 * @return int id, o 0 si no venía ningún valor.
	 */
	public static function medir( $valores, $fecha = '' ) {
		$fecha = Malka_CRM_Helpers::sanitize_date( $fecha );

		if ( '' === $fecha ) {
			$fecha = current_time( 'Y-m-d' );
		}

		$d       = self::datos();
		$limpios = array();

		foreach ( (array) $valores as $k => $v ) {
			$k = sanitize_key( $k );
			$v = self::numero_medida( $v );

			if ( '' === $v || ! is_numeric( $v ) ) {
				continue;
			}

			$n = (float) $v;

			// Un número negativo no es una medida del cuerpo.
			if ( $n <= 0 ) {
				continue;
			}

			$limpios[ $k ] = round( $n, 2 );
		}

		if ( ! $limpios ) {
			return 0;
		}

		$id = 1;

		foreach ( $d['medidas'] as $m ) {
			if ( (int) $m['id'] >= $id ) {
				$id = (int) $m['id'] + 1;
			}
		}

		/*
		 * Dos mediciones el mismo día se juntan en una: se mide una vez al
		 * día, y dos puntos en la misma fecha harían una línea que va y
		 * vuelve sin querer decir nada.
		 */
		foreach ( $d['medidas'] as $i => $m ) {
			if ( $m['fecha'] === $fecha ) {
				$d['medidas'][ $i ]['valores'] = array_merge( $m['valores'], $limpios );
				self::guardar_todo( $d );
				return (int) $m['id'];
			}
		}

		$d['medidas'][] = array(
			'id'      => $id,
			'fecha'   => $fecha,
			'valores' => $limpios,
		);

		if ( count( $d['medidas'] ) > self::TOPE ) {
			$d['medidas'] = array_slice( $d['medidas'], count( $d['medidas'] ) - self::TOPE );
		}

		self::guardar_todo( $d );

		return $id;
	}

	/**
	 * Corrige un registro pasado.
	 *
	 * Reemplaza los valores en vez de mezclarlos: si ella borra un
	 * número al corregir, es porque quiere que no esté. Mezclando, un
	 * valor mal anotado no habría forma de sacarlo.
	 *
	 * @param int    $id      Cuál.
	 * @param array  $valores clave => número.
	 * @param string $fecha   Y-m-d. Vacío: la deja como estaba.
	 * @return bool Si existía.
	 */
	public static function editar( $id, $valores, $fecha = '' ) {
		$id = (int) $id;
		$d  = self::datos();

		foreach ( $d['medidas'] as $i => $m ) {
			if ( (int) $m['id'] !== $id ) {
				continue;
			}

			$limpios = array();

			foreach ( (array) $valores as $k => $v ) {
				$k = sanitize_key( $k );
				$v = self::numero_medida( $v );

				if ( '' === $v || ! is_numeric( $v ) || (float) $v <= 0 ) {
					continue;
				}

				$limpios[ $k ] = round( (float) $v, 2 );
			}

			$f = Malka_CRM_Helpers::sanitize_date( $fecha );

			if ( '' !== $f && $f <= current_time( 'Y-m-d' ) ) {
				$d['medidas'][ $i ]['fecha'] = $f;
			}

			/*
			 * Si no queda ningún valor, el registro ya no dice nada y se
			 * va. Dejarlo sería una fila vacía en la tabla para siempre.
			 */
			if ( ! $limpios ) {
				unset( $d['medidas'][ $i ] );
				$d['medidas'] = array_values( $d['medidas'] );
				self::guardar_todo( $d );

				return true;
			}

			$d['medidas'][ $i ]['valores'] = $limpios;
			self::guardar_todo( $d );

			return true;
		}

		return false;
	}

	/**
	 * Borra una medición.
	 *
	 * @param int $id Id.
	 * @return bool
	 */
	public static function medida_borrar( $id ) {
		$id = (int) $id;
		$d  = self::datos();

		foreach ( $d['medidas'] as $i => $m ) {
			if ( (int) $m['id'] === $id ) {
				unset( $d['medidas'][ $i ] );
				$d['medidas'] = array_values( $d['medidas'] );
				self::guardar_todo( $d );
				return true;
			}
		}

		return false;
	}

	/**
	 * Lo medido, de lo más nuevo a lo más viejo.
	 *
	 * @return array[]
	 */
	public static function medidas() {
		$d = self::datos();
		$m = $d['medidas'];

		usort(
			$m,
			function ( $a, $b ) {
				return strcmp( $b['fecha'], $a['fecha'] );
			}
		);

		return $m;
	}

	/**
	 * La serie de una medida, de la más vieja a la más nueva.
	 *
	 * @param string $clave Cuál.
	 * @param int    $tope  Cuántos puntos como máximo.
	 * @return array[] fecha, valor.
	 */
	public static function serie( $clave, $tope = 40 ) {
		$clave = sanitize_key( $clave );
		$out   = array();

		foreach ( array_reverse( self::medidas() ) as $m ) {
			if ( isset( $m['valores'][ $clave ] ) ) {
				$out[] = array(
					'fecha' => $m['fecha'],
					'valor' => (float) $m['valores'][ $clave ],
				);
			}
		}

		if ( count( $out ) > $tope ) {
			$out = array_slice( $out, count( $out ) - $tope );
		}

		return $out;
	}

	/* ─────────────────────────────  Pantallas  ────────────────────────── */

	/**
	 * El resumen: cómo viene hoy, en dos líneas.
	 *
	 * No repite los nombres de las solapas —eso ya está arriba— sino el
	 * estado: cuántos hábitos van hoy y cuál fue la última medición.
	 *
	 * @return string
	 */
	public static function resumen() {
		$habitos = self::habitos();
		$medidas = self::medidas();
		$tipos   = self::tipos();

		ob_start();
		echo '<div class="esc-bien__r">';

		// Hábitos de hoy.
		echo '<div class="esc-bien__c">';
		printf( '<span class="esc-lbl">%s</span>', esc_html__( 'Hábitos de hoy', 'malka-crm' ) );

		if ( ! $habitos ) {
			printf(
				'<p class="esc-bien__v"><a href="%1$s">%2$s</a></p>',
				esc_url( Malka_CRM_Dashboard::view_url( 'habitos' ) ),
				esc_html__( 'Todavía no hay ninguno', 'malka-crm' )
			);
		} else {
			$van = 0;

			foreach ( $habitos as $h ) {
				if ( $h['hoy'] ) {
					$van++;
				}
			}

			printf(
				'<p class="esc-bien__n"><a href="%1$s"><em>%2$d</em> <span>%3$s</span></a></p>',
				esc_url( Malka_CRM_Dashboard::view_url( 'habitos' ) ),
				(int) $van,
				esc_html(
					sprintf(
						/* translators: cuántos hábitos hay en total */
						__( 'de %d', 'malka-crm' ),
						count( $habitos )
					)
				)
			);

			// Los que faltan, por su nombre: el número solo no dice qué hacer.
			$faltan = array();

			foreach ( $habitos as $h ) {
				if ( ! $h['hoy'] ) {
					$faltan[] = $h['nombre'];
				}
			}

			if ( $faltan ) {
				printf(
					'<p class="esc-bien__d">%s</p>',
					esc_html(
						sprintf(
							/* translators: los hábitos que faltan */
							__( 'Falta: %s', 'malka-crm' ),
							implode( ', ', array_slice( $faltan, 0, 4 ) )
						)
					)
				);
			}
		}

		echo '</div>';

		// La última medición.
		echo '<div class="esc-bien__c">';
		printf( '<span class="esc-lbl">%s</span>', esc_html__( 'Última medición', 'malka-crm' ) );

		if ( ! $medidas ) {
			printf(
				'<p class="esc-bien__v"><a href="%1$s">%2$s</a></p>',
				esc_url( Malka_CRM_Dashboard::view_url( 'cuerpo' ) ),
				esc_html__( 'Todavía no hay nada anotado', 'malka-crm' )
			);
		} else {
			$u = $medidas[0];

			/*
			 * Antes salían las nueve medidas seguidas, subrayadas, como un
			 * link de cuatro líneas: nadie lee eso de un vistazo, que es lo
			 * único que este bloque promete. Van la fecha primero y tres
			 * números; el resto está a un clic, en Cuerpo.
			 */
			printf(
				'<p class="esc-bien__d">%s</p>',
				esc_html( date_i18n( 'j \d\e F', strtotime( $u['fecha'] ) ) )
			);

			/*
			 * Tres números, no nueve. Peso, grasa e IMC van primero porque
			 * son los que ella mira; si alguno no está medido o no existe
			 * como tipo, el hueco lo llena la medida siguiente en vez de
			 * dejar la caja coja.
			 */
			$tope        = 3;
			$principales = array();

			foreach ( array( 'peso', 'grasa', 'imc' ) as $clave ) {
				if ( count( $principales ) >= $tope ) {
					break;
				}

				foreach ( $tipos as $cand ) {
					if ( $cand['clave'] === $clave && isset( $u['valores'][ $clave ] ) ) {
						$principales[] = $cand;
						break;
					}
				}
			}

			foreach ( $tipos as $cand ) {
				if ( count( $principales ) >= $tope ) {
					break;
				}

				if ( ! isset( $u['valores'][ $cand['clave'] ] ) ) {
					continue;
				}

				if ( in_array( $cand['clave'], wp_list_pluck( $principales, 'clave' ), true ) ) {
					continue;
				}

				$principales[] = $cand;
			}

			$cajas = array();

			foreach ( $principales as $t ) {
				$clave = $t['clave'];

				$cajas[] = sprintf(
					'<span class="esc-bien__m"><b>%1$s</b><small>%2$s</small></span>',
					esc_html(
						number_format_i18n( (float) $u['valores'][ $clave ], isset( $t['dec'] ) ? (int) $t['dec'] : 1 )
						. ( $t['unidad'] ? ' ' . $t['unidad'] : '' )
					),
					esc_html( $t['nombre'] )
				);
			}

			if ( $cajas ) {
				echo '<p class="esc-bien__ms">' . implode( '', $cajas ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			/*
			 * Lo que falta por ver es lo que Cuerpo muestra, y Cuerpo sólo
			 * muestra las medidas que existen como tipo: contar el resto
			 * prometería datos que al hacer clic no están.
			 */
			$cuantas = 0;

			foreach ( $tipos as $cand ) {
				if ( isset( $u['valores'][ $cand['clave'] ] ) ) {
					$cuantas++;
				}
			}

			$cuantas -= count( $cajas );

			printf(
				'<p class="esc-bien__ver"><a href="%1$s">%2$s</a></p>',
				esc_url( Malka_CRM_Dashboard::view_url( 'cuerpo' ) ),
				esc_html(
					$cuantas > 0
						? sprintf(
							/* translators: cuántas medidas más hay */
							_n( 'Ver la medición completa (%d dato más)', 'Ver la medición completa (%d datos más)', $cuantas, 'malka-crm' ),
							$cuantas
						)
						: __( 'Ver la medición completa', 'malka-crm' )
				)
			);
		}

		echo '</div></div>';

		printf(
			'<p class="esc-hint">%s</p>',
			esc_html__( 'Mente, Vínculos y Vos todavía están vacíos: por ahora son el lugar, no el contenido.', 'malka-crm' )
		);

		return ob_get_clean();
	}

	/**
	 * La racha de un hábito, dicha en palabras.
	 *
	 * Se dice, no se celebra ni se reclama: cortar una racha es normal y
	 * una pantalla que lo retara serviría para dejar de abrirla.
	 *
	 * Vive acá y no en el JavaScript porque los plurales del castellano
	 * son del servidor, que es el que tiene las traducciones.
	 *
	 * @param int $racha Días seguidos.
	 * @param int $total Veces en total.
	 * @return string Puede venir vacía.
	 */
	public static function racha_dicha( $racha, $total ) {
		$racha = (int) $racha;
		$total = (int) $total;

		if ( $racha > 1 ) {
			/* translators: cantidad de días */
			return sprintf( _n( '%d día seguido', '%d días seguidos', $racha, 'malka-crm' ), $racha );
		}

		if ( $total > 0 ) {
			/* translators: cantidad de veces */
			return sprintf( _n( '%d vez en total', '%d veces en total', $total, 'malka-crm' ), $total );
		}

		return '';
	}

	/**
	 * Hábitos: marcar el día y ver la racha.
	 *
	 * @return string
	 */
	public static function render_habitos() {
		// Qué día se está mirando. Por defecto hoy; se puede retroceder
		// para marcar lo que se olvidó o desmarcar lo que se marcó mal.
		$dia = self::dia_valido(
			isset( $_GET['dia'] ) ? sanitize_text_field( wp_unslash( $_GET['dia'] ) ) : '' // phpcs:ignore WordPress.Security.NonceVerification
		);

		$hoy     = current_time( 'Y-m-d' );
		$es_hoy  = ( $dia === $hoy );
		$habitos = self::habitos( $dia );

		ob_start();
		printf(
			'<section class="esc-panel esc-hab" id="esc-habitos" data-nonce="%s" data-dia="%s">',
			esc_attr( wp_create_nonce( 'malka_crm_inicio' ) ),
			esc_attr( $dia )
		);

		echo Malka_CRM_Dashboard::head( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'bienestar',
			__( 'Hábitos', 'malka-crm' ),
			__( 'Lo que quieres hacer seguido. Se marca el día que lo hiciste.', 'malka-crm' ),
			$habitos ? (string) count( array_filter( $habitos, function ( $h ) { return $h['hoy']; } ) ) . '/' . count( $habitos ) : '',
			$habitos ? ( $es_hoy ? __( 'hoy', 'malka-crm' ) : __( 'ese día', 'malka-crm' ) ) : '',
			''
		);

		/*
		 * El paso de días. Sin esto, olvidarse de marcar un día era
		 * perderlo para siempre, y marcar el que no era no tenía vuelta.
		 */
		if ( $habitos ) {
			$ayer    = gmdate( 'Y-m-d', strtotime( $dia . ' -1 day' ) );
			$manana  = gmdate( 'Y-m-d', strtotime( $dia . ' +1 day' ) );
			$url     = Malka_CRM_Dashboard::view_url( 'habitos' );
			$con_dia = function ( $d ) use ( $url ) {
				return add_query_arg( 'dia', $d, $url );
			};

			echo '<nav class="esc-hab__dias" aria-label="' . esc_attr__( 'Qué día', 'malka-crm' ) . '">';

			printf(
				'<a class="esc-hab__p" href="%1$s" rel="prev" aria-label="%2$s" title="%2$s">&#8249;</a>',
				esc_url( $con_dia( $ayer ) ),
				esc_attr__( 'El día anterior', 'malka-crm' )
			);

			printf(
				'<b>%s</b>',
				esc_html(
					$es_hoy
						? __( 'Hoy', 'malka-crm' )
						: date_i18n( 'l j \d\e F', strtotime( $dia ) )
				)
			);

			if ( $es_hoy ) {
				printf(
					'<span class="esc-hab__p is-no" aria-hidden="true">&#8250;</span>'
				);
			} else {
				printf(
					'<a class="esc-hab__p" href="%1$s" rel="next" aria-label="%2$s" title="%2$s">&#8250;</a>',
					esc_url( $con_dia( $manana ) ),
					esc_attr__( 'El día siguiente', 'malka-crm' )
				);

				printf(
					'<a class="esc-hab__hoy" href="%1$s">%2$s</a>',
					esc_url( $url ),
					esc_html__( 'Volver a hoy', 'malka-crm' )
				);
			}

			echo '</nav>';
		}

		if ( ! $habitos ) {
			printf(
				'<p class="esc-empty">%s</p>',
				esc_html__( 'Todavía no hay ninguno. Agrega uno abajo: con marcarlo los días que lo hagas alcanza, no hay nada más que llenar.', 'malka-crm' )
			);
		} else {
			echo '<ul class="esc-hab__l">';

			/* translators: nombre del hábito */
			$poner = function ( $n ) { return sprintf( __( 'Marcar %s como hecho hoy', 'malka-crm' ), $n ); };
			/* translators: nombre del hábito */
			$quitar = function ( $n ) { return sprintf( __( 'Desmarcar %s de hoy', 'malka-crm' ), $n ); };

			foreach ( $habitos as $h ) {
				echo '<li class="esc-hab__i">';
				printf(
					'<button type="button" class="esc-dia__chk esc-hab__ck%1$s" data-habito="%2$d" aria-pressed="%3$s"' .
					' aria-label="%4$s" title="%4$s" data-poner="%5$s" data-quitar="%6$s"></button>',
					$h['hoy'] ? ' is-on' : '',
					(int) $h['id'],
					$h['hoy'] ? 'true' : 'false',
					esc_attr( $h['hoy'] ? $quitar( $h['nombre'] ) : $poner( $h['nombre'] ) ),
					esc_attr( $poner( $h['nombre'] ) ),
					esc_attr( $quitar( $h['nombre'] ) )
				);

				echo '<span class="esc-hab__t">';
				printf( '<b>%s</b>', esc_html( $h['nombre'] ) );

				/*
				 * La racha se dice, no se celebra ni se reclama. Cortar una
				 * racha es normal; una pantalla que lo retara serviría para
				 * dejar de abrirla.
				 */
				printf(
					'<i data-racha>%s</i>',
					esc_html( self::racha_dicha( $h['racha'], $h['total'] ) )
				);

				echo '</span>';

				// Las últimas cuatro semanas, de un vistazo.
				echo '<span class="esc-hab__m" aria-hidden="true">';

				/*
				 * El punto del día que se está mirando va marcado para
				 * poder pintarlo sin recargar. No es siempre el último:
				 * si se está corrigiendo el martes, es el del martes.
				 */
				foreach ( $h['mes'] as $d ) {
					printf(
						'<i class="%1$s"%2$s title="%3$s"></i>',
						$d['hecho'] ? 'on' : '',
						$d['fecha'] === $dia ? ' data-hoy' : '',
						esc_attr( date_i18n( 'j M', strtotime( $d['fecha'] ) ) )
					);
				}

				echo '</span>';
				echo self::form_borrar_habito( $h['id'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '</li>';
			}

			echo '</ul>';
		}

		echo self::form_habito_nuevo(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</section>';

		return ob_get_clean();
	}

	/**
	 * El formulario para agregar un hábito.
	 *
	 * @return string
	 */
	private static function form_habito_nuevo() {
		ob_start();
		printf( '<form class="esc-hab__n" method="post" action="%s">', esc_url( admin_url( 'admin-post.php' ) ) );
		wp_nonce_field( 'malka_crm_habito_nuevo', '_wpnonce' );
		echo '<input type="hidden" name="action" value="malka_crm_habito_nuevo" />';
		printf(
			'<label><span>%1$s</span><input type="text" name="nombre" placeholder="%2$s" required /></label>',
			esc_html__( 'Agregar un hábito', 'malka-crm' ),
			esc_attr__( 'Caminar, leer, tomar agua…', 'malka-crm' )
		);
		printf( '<button type="submit" class="esc-btn esc-btn--primary">%s</button>', esc_html__( 'Agregar', 'malka-crm' ) );
		echo '</form>';

		return ob_get_clean();
	}

	/**
	 * El botón de sacar un hábito de la lista.
	 *
	 * @param int $id Id.
	 * @return string
	 */
	private static function form_borrar_habito( $id ) {
		return sprintf(
			'<form method="post" action="%1$s" class="esc-hab__x">%2$s' .
			'<input type="hidden" name="action" value="malka_crm_habito_borrar" />' .
			'<input type="hidden" name="id" value="%3$d" />' .
			'<button type="submit" class="esc-mini" aria-label="%4$s" title="%4$s">%5$s</button></form>',
			esc_url( admin_url( 'admin-post.php' ) ),
			wp_nonce_field( 'malka_crm_habito_borrar', '_wpnonce', true, false ),
			(int) $id,
			esc_attr__( 'Sacar de la lista', 'malka-crm' ),
			esc_html__( 'Sacar', 'malka-crm' )
		);
	}

	/**
	 * Cuerpo: el registro de medidas y cómo vienen.
	 *
	 * A propósito sin metas, sin rangos y sin decir si un número está bien
	 * o mal. Es un cuaderno con su línea en el tiempo: lo que significan
	 * esos números lo dice quien corresponde.
	 *
	 * @return string
	 */
	public static function render_cuerpo() {
		$tipos   = self::tipos();
		$medidas = self::medidas();

		ob_start();
		echo '<section class="esc-panel esc-med" id="esc-medidas">';

		echo Malka_CRM_Dashboard::head( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'cuerpo',
			__( 'Tus medidas', 'malka-crm' ),
			__( 'Lo que mides, cuándo lo mediste y cómo viene', 'malka-crm' ),
			$medidas ? (string) count( $medidas ) : '',
			$medidas ? __( 'registros', 'malka-crm' ) : '',
			''
		);

		/*
		 * El orden de la pantalla es el orden en que se usa:
		 *
		 * 1. Anotar, que es lo de todos los días y va primero.
		 * 2. Lo anotado: los gráficos y la tabla. Es a lo que se entra.
		 * 3. Los ajustes —qué mides, tus metas— detrás de UNA sola
		 *    puerta, porque se tocan una vez cada tanto.
		 *
		 * Antes los tres formularios de configuración estaban abiertos
		 * arriba y los datos quedaban al final: se entraba a ver cómo
		 * viene el peso y lo primero eran tres formularios.
		 */
		echo self::form_medir( $tipos ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( ! $medidas ) {
			printf(
				'<div class="esc-med__vacio"><p>%1$s</p><p class="esc-hint">%2$s</p></div>',
				esc_html__( 'Todavía no hay nada anotado.', 'malka-crm' ),
				esc_html__( 'Anota arriba. En Ajustes agregas lo que quieras seguir.', 'malka-crm' )
			);
		} else {
			$graficos = '';

			foreach ( $tipos as $t ) {
				$serie = self::serie( $t['clave'] );

				if ( count( $serie ) < 2 ) {
					continue;
				}

				$graficos .= self::linea( $t, $serie );
			}

			if ( $graficos ) {
				echo '<div class="esc-med__gs">' . $graficos . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				printf(
					'<p class="esc-hint esc-med__p">%s</p>',
					esc_html__( 'Con una sola medición no hay línea todavía.', 'malka-crm' )
				);
			}

			echo self::tabla_medidas( $tipos, array_slice( $medidas, 0, 40 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo self::ajustes( $tipos ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</section>';

		return ob_get_clean();
	}

	/**
	 * Todo lo que se configura, detrás de una sola puerta.
	 *
	 * Qué mides, tus metas y el dibujo de dónde se mide cada cosa. Son
	 * cosas que se tocan una vez cada tanto, así que no pueden estar
	 * compitiendo con lo de todos los días, que es anotar y mirar.
	 *
	 * @param array[] $tipos Qué se mide.
	 * @return string
	 */
	private static function ajustes( $tipos ) {
		ob_start();
		printf(
			'<details class="esc-med__cfg"><summary>%s</summary><div class="esc-med__cfgc">',
			esc_html__( 'Ajustes de medidas', 'malka-crm' )
		);

		/* ── Qué mides ── */
		printf( '<h3 class="esc-lbl">%s</h3>', esc_html__( 'Qué mides', 'malka-crm' ) );
		echo self::diagrama( $tipos ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		/* ── Tus metas ── */
		printf( '<h3 class="esc-lbl">%s</h3>', esc_html__( 'Tus metas', 'malka-crm' ) );
		printf(
			'<p class="esc-hint">%s</p>',
			esc_html__( 'Las metas las pones tú: salen como una raya en el gráfico. Para sacar una, deja el campo vacío.', 'malka-crm' )
		);
		printf( '<form class="esc-med__n" method="post" action="%s">', esc_url( admin_url( 'admin-post.php' ) ) );
		wp_nonce_field( 'malka_crm_medida_meta', '_wpnonce' );
		echo '<input type="hidden" name="action" value="malka_crm_medida_meta" />';

		foreach ( $tipos as $t ) {
			printf(
				'<label><span>%1$s</span><input type="text" inputmode="decimal" name="m[%2$s]" value="%3$s" placeholder="%4$s" /></label>',
				esc_html( $t['nombre'] . ( $t['unidad'] ? ' (' . $t['unidad'] . ')' : '' ) ),
				esc_attr( $t['clave'] ),
				esc_attr( isset( $t['meta'] ) ? $t['meta'] : '' ),
				esc_attr__( 'sin meta', 'malka-crm' )
			);
		}

		printf( '<button type="submit" class="esc-btn">%s</button>', esc_html__( 'Guardar metas', 'malka-crm' ) );
		echo '</form>';

		/* ── Algo que no está en el dibujo ── */
		printf( '<h3 class="esc-lbl">%s</h3>', esc_html__( 'Medir otra cosa', 'malka-crm' ) );
		printf( '<form class="esc-med__n" method="post" action="%s">', esc_url( admin_url( 'admin-post.php' ) ) );
		wp_nonce_field( 'malka_crm_medida_tipo', '_wpnonce' );
		echo '<input type="hidden" name="action" value="malka_crm_medida_tipo" />';
		printf(
			'<label><span>%1$s</span><input type="text" name="nombre" placeholder="%2$s" required /></label>',
			esc_html__( 'Qué', 'malka-crm' ),
			esc_attr__( 'Presión, horas de sueño…', 'malka-crm' )
		);
		printf(
			'<label><span>%1$s</span><input type="text" name="unidad" placeholder="%2$s" /></label>',
			esc_html__( 'En qué', 'malka-crm' ),
			esc_attr__( 'cm, kg, %…', 'malka-crm' )
		);
		printf( '<button type="submit" class="esc-btn">%s</button>', esc_html__( 'Agregar', 'malka-crm' ) );
		echo '</form>';

		/*
		 * Dónde quedan estos datos. Va acá abajo, una vez, en vez de
		 * arriba de todo: lo importante es decirlo, no repetirlo cada
		 * vez que entra a anotar su peso.
		 */
		printf(
			'<p class="esc-hint esc-med__priv">%s</p>',
			esc_html__( 'Se guarda en tu propio sitio y no sale a ninguna parte. El panel no opina sobre tus números.', 'malka-crm' )
		);

		echo '</div></details>';

		return ob_get_clean();
	}

	/**
	 * Qué silueta se está mostrando.
	 *
	 * @return string 'f' o 'm'.
	 */
	public static function silueta() {
		$d = self::datos();

		return $d['silueta'];
	}

	/**
	 * Cambia la silueta del dibujo.
	 *
	 * Es el dibujo de referencia y nada más: no toca lo que se mide ni
	 * lo anotado, y por eso cambiarla no puede perder nada.
	 *
	 * @param string $cual 'f' o 'm'.
	 * @return string La que quedó.
	 */
	public static function poner_silueta( $cual ) {
		$cual = 'm' === $cual ? 'm' : 'f';
		$d    = self::datos();

		$d['silueta'] = $cual;
		self::guardar_todo( $d );

		return $cual;
	}

	/**
	 * Los puntos del dibujo, en orden.
	 *
	 * El número del dibujo es la posición en esta lista. Agregar uno al
	 * final no mueve los que ya están.
	 *
	 * @return array[] clave => nombre, unidad.
	 */
	public static function puntos() {
		return array(
			'cuello'      => array(
				__( 'Cuello', 'malka-crm' ),
				'cm',
				__( 'Justo debajo de la nuez, con la cinta horizontal y apoyada sin apretar.', 'malka-crm' ),
			),
			'pecho'       => array(
				__( 'Pecho', 'malka-crm' ),
				'cm',
				__( 'A la altura de los pezones, con la cinta horizontal por la espalda. Al final de una espiración normal, sin inflar el pecho.', 'malka-crm' ),
			),
			'cintura'     => array(
				__( 'Cintura', 'malka-crm' ),
				'cm',
				__( 'En la parte más angosta, entre la última costilla y el hueso de la cadera. De pie, relajada: no metas la guata ni aprietes la cinta.', 'malka-crm' ),
			),
			'cadera'      => array(
				__( 'Cadera', 'malka-crm' ),
				'cm',
				__( 'En la parte más ancha de los glúteos, con los pies juntos y la cinta horizontal.', 'malka-crm' ),
			),
			'muslo'       => array(
				__( 'Muslo', 'malka-crm' ),
				'cm',
				__( 'A mitad de camino entre la ingle y la rodilla. De pie, con el peso repartido en las dos piernas.', 'malka-crm' ),
			),
			'pantorrilla' => array(
				__( 'Pantorrilla', 'malka-crm' ),
				'cm',
				__( 'En la parte más gruesa, de pie y con el peso repartido.', 'malka-crm' ),
			),
			'brazo'       => array(
				__( 'Brazo', 'malka-crm' ),
				'cm',
				__( 'Brazo colgando y relajado, a mitad de camino entre el hombro y el codo. Sin apretar el músculo.', 'malka-crm' ),
			),
			'antebrazo'   => array(
				__( 'Antebrazo', 'malka-crm' ),
				'cm',
				__( 'En la parte más gruesa, con el brazo colgando y la mano suelta.', 'malka-crm' ),
			),
			'muneca'      => array(
				__( 'Muñeca', 'malka-crm' ),
				'cm',
				__( 'En la parte más angosta, justo debajo del hueso que sobresale.', 'malka-crm' ),
			),
			'altura'      => array(
				__( 'Altura', 'malka-crm' ),
				'cm',
				__( 'Descalza, talones juntos y contra la pared, mirando al frente. Mejor en la mañana: durante el día se pierde hasta un centímetro.', 'malka-crm' ),
			),
		);
	}

	/**
	 * Los pliegues, que se miden con cáliper y en milímetros.
	 *
	 * Van aparte de las circunferencias porque es otra técnica: se toma
	 * el pliegue con los dedos, se aplica el cáliper un centímetro más
	 * abajo y se lee a los dos segundos. Siempre del mismo lado del
	 * cuerpo, y conviene repetir dos o tres veces y quedarse con el
	 * valor del medio.
	 *
	 * @return array[] clave => nombre, unidad, cómo se toma.
	 */
	public static function pliegues() {
		return array(
			'pl_triceps'     => array(
				__( 'Pliegue tríceps', 'malka-crm' ),
				'mm',
				__( 'Vertical, en la cara de atrás del brazo, a mitad de camino entre el hombro y el codo. Brazo colgando y relajado.', 'malka-crm' ),
			),
			'pl_biceps'      => array(
				__( 'Pliegue bíceps', 'malka-crm' ),
				'mm',
				__( 'Vertical, en la cara de adelante del brazo, a la misma altura que el de tríceps.', 'malka-crm' ),
			),
			'pl_subescap'    => array(
				__( 'Pliegue subescapular', 'malka-crm' ),
				'mm',
				__( 'En diagonal, siguiendo la línea de la costilla, justo debajo de la punta de abajo del omóplato. Necesitas que alguien te lo tome.', 'malka-crm' ),
			),
			'pl_suprailiaco' => array(
				__( 'Pliegue suprailíaco', 'malka-crm' ),
				'mm',
				__( 'En diagonal, justo encima del hueso de la cadera, en la línea que baja desde la axila.', 'malka-crm' ),
			),
			'pl_abdominal'   => array(
				__( 'Pliegue abdominal', 'malka-crm' ),
				'mm',
				__( 'Vertical, a dos centímetros al lado del ombligo. De pie y con la guata relajada.', 'malka-crm' ),
			),
			'pl_muslo'       => array(
				__( 'Pliegue muslo', 'malka-crm' ),
				'mm',
				__( 'Vertical, en la cara de adelante del muslo, a mitad entre la ingle y el borde de arriba de la rótula.', 'malka-crm' ),
			),
			'pl_pantorrilla' => array(
				__( 'Pliegue pantorrilla', 'malka-crm' ),
				'mm',
				__( 'Vertical, en la cara interna de la pantorrilla, en la parte más gruesa. Sentada, con la rodilla en ángulo recto.', 'malka-crm' ),
			),
		);
	}

	/**
	 * Lo que entrega una balanza de bioimpedancia.
	 *
	 * Estos números no se miden: se copian de la pantalla de la balanza.
	 * Por eso la indicación de cada uno no es cómo tomarlo sino en qué
	 * condiciones vale la pena compararlo: la bioimpedancia manda una
	 * corriente por el cuerpo y el agua que tengas encima la cambia, así
	 * que el valor absoluto se mueve harto de un día para otro. Medido
	 * siempre igual —misma hora, descalza, antes de comer— la tendencia
	 * sí sirve.
	 *
	 * @return array[] clave => nombre, unidad, cuándo tomarlo.
	 */
	public static function balanza() {
		$mismo = __( 'Siempre en las mismas condiciones: a la misma hora, descalza, antes de comer o tomar agua y después de ir al baño. Si cambian las condiciones, el número cambia aunque tu cuerpo no.', 'malka-crm' );

		return array(
			'imc'        => array(
				__( 'IMC', 'malka-crm' ),
				'',
				__( 'Lo calcula la balanza con tu peso y tu altura. Si la altura que tiene guardada está mal, el número está mal.', 'malka-crm' ),
			),
			'metabolismo' => array(
				__( 'Metabolismo basal', 'malka-crm' ),
				'kcal/d',
				__( 'Lo que la balanza estima que gastas en reposo. Es una estimación a partir de tu peso y composición, no una medición.', 'malka-crm' ),
			),
			'visceral'   => array(
				__( 'Grasa visceral', 'malka-crm' ),
				'',
				$mismo,
			),
			'musculo'    => array(
				__( 'Masa muscular', 'malka-crm' ),
				'kg',
				$mismo,
			),
			'hueso'      => array(
				__( 'Minerales en los huesos', 'malka-crm' ),
				'kg',
				$mismo,
			),
			'proteina'   => array(
				__( 'Proteínas', 'malka-crm' ),
				'%',
				$mismo,
			),
			'agua'       => array(
				__( 'Agua en el cuerpo', 'malka-crm' ),
				'%',
				__( 'El que más se mueve de todos: sube y baja con lo que tomaste, la hora y el ciclo. Compáralo sólo entre mediciones tomadas igual.', 'malka-crm' ),
			),
		);
	}

	/**
	 * Todo lo que el panel sabe tomar.
	 *
	 * @return array[]
	 */
	public static function catalogo() {
		return array_merge( self::puntos(), self::pliegues(), self::balanza() );
	}

	/**
	 * Agrega la medida de un punto del dibujo.
	 *
	 * Sólo los del dibujo. El valor llega de un formulario, así que lo
	 * que no esté en la lista no entra: si no, cualquiera podría crear
	 * medidas con el nombre que quisiera mandando otro valor.
	 *
	 * @param string $punto La clave.
	 * @return string La clave creada, o '' si no era del dibujo.
	 */
	public static function agregar_punto( $punto ) {
		$puntos = self::catalogo();
		$punto  = sanitize_key( (string) $punto );

		if ( ! isset( $puntos[ $punto ] ) ) {
			return '';
		}

		/*
		 * El mismo botón pone y saca. Si ya la mide, la saca de la lista
		 * —pero NO borra lo anotado: dejar de seguir la cintura no es lo
		 * mismo que tirar seis meses de mediciones. Si la vuelve a
		 * agregar, aparecen de nuevo.
		 */
		foreach ( self::tipos() as $t ) {
			if ( $t['clave'] === $punto ) {
				self::quitar_tipo( $punto );
				return '';
			}
		}

		return self::tipo_nuevo( $puntos[ $punto ][0], $puntos[ $punto ][1], $punto );
	}

	/**
	 * Deja de seguir una medida, sin borrar lo anotado.
	 *
	 * @param string $clave Cuál.
	 * @return bool Si estaba.
	 */
	public static function quitar_tipo( $clave ) {
		$clave = sanitize_key( $clave );
		$d     = self::datos();

		foreach ( $d['tipos'] as $i => $t ) {
			if ( $t['clave'] !== $clave ) {
				continue;
			}

			unset( $d['tipos'][ $i ] );
			$d['tipos'] = array_values( $d['tipos'] );
			self::guardar_todo( $d );

			return true;
		}

		return false;
	}

	/**
	 * El dibujo con dónde se mide cada cosa.
	 *
	 * No es un adorno: cada número del dibujo es un botón que agrega esa
	 * medida a tu lista. Así no hay que acordarse de cómo se llama cada
	 * punto ni escribirlo bien, que es justo lo que hace que una lista de
	 * medidas se llene a medias.
	 *
	 * Los que ya mides salen marcados y sin botón.
	 *
	 * @return string
	 */
	public static function diagrama( $tipos = null ) {
		$tengo = wp_list_pluck( null === $tipos ? self::tipos() : $tipos, 'clave' );
		$cual  = self::silueta();

		/*
		 * Las dos siluetas, armadas por piezas y fusionadas: cabeza,
		 * torso, brazos, piernas y pies se unen y se toma sólo el borde
		 * de afuera. Dibujando el contorno a mano salían líneas cruzadas
		 * y puntas donde el muslo asomaba por el costado de la cadera.
		 */
		$cuerpos = array(
			'f' => 'M 91.2 271.9 C 91.6 278.9, 93.4 287.3, 94.6 292.1 C 95.8 296.8, 97.7 298.8, 98.5 300.3 C 99.3 301.8, 99.1 300.8, 99.4 300.9 C 99.8 301.1, 100.1 301.4, 100.7 300.9 C 101.2 300.4, 102.1 300.7, 102.8 297.9 C 103.5 295.1, 104.7 291.9, 104.9 283.9 C 105.1 276.0, 104.1 257.6, 104.0 249.9 C 103.9 242.3, 102.9 252.9, 104.5 238.0 C 106.1 223.0, 111.9 173.2, 113.5 160.0 C 115.1 146.9, 113.8 159.1, 114.1 158.9 C 114.5 158.6, 115.0 158.4, 115.4 158.6 C 115.8 158.7, 115.9 157.4, 116.6 159.6 C 117.4 161.8, 118.4 165.6, 120.0 171.9 C 121.5 178.3, 125.9 190.6, 125.9 197.9 C 125.9 205.3, 122.5 209.1, 120.0 216.0 C 117.5 222.9, 112.2 232.9, 111.0 239.2 C 109.9 245.5, 112.4 250.8, 113.0 253.9 C 113.5 257.0, 114.2 254.9, 114.3 257.6 C 114.5 260.2, 113.8 261.7, 114.0 270.1 C 114.2 278.5, 114.3 294.4, 115.5 308.0 C 116.8 321.7, 120.7 341.3, 121.5 352.0 C 122.2 362.7, 120.4 364.3, 120.0 372.0 C 119.6 379.7, 118.0 388.0, 119.0 398.0 C 120.0 408.0, 124.5 423.3, 126.0 431.9 C 127.5 440.6, 128.4 444.9, 127.9 449.9 C 127.4 454.9, 124.1 458.5, 123.0 462.0 C 121.9 465.4, 121.4 469.0, 121.4 470.7 C 121.4 472.4, 119.4 471.8, 122.8 472.0 C 126.3 472.2, 138.8 472.1, 142.3 472.0 C 145.7 471.9, 143.1 471.8, 143.3 471.6 C 143.6 471.4, 144.1 474.5, 143.8 470.7 C 143.6 466.9, 142.0 455.4, 141.6 448.9 C 141.3 442.5, 141.4 440.5, 142.0 432.0 C 142.6 423.5, 144.7 407.9, 145.0 397.9 C 145.3 387.9, 144.4 379.7, 144.0 372.0 C 143.6 364.4, 141.8 366.1, 142.5 352.0 C 143.2 337.9, 147.3 298.3, 148.4 287.3 C 149.5 276.4, 148.6 286.5, 148.9 286.3 C 149.2 286.0, 149.7 285.8, 150.1 285.8 C 150.4 285.8, 150.8 286.0, 151.1 286.3 C 151.4 286.5, 150.5 276.4, 151.6 287.3 C 152.7 298.3, 156.8 337.8, 157.5 351.9 C 158.2 366.0, 156.4 364.3, 156.0 372.0 C 155.6 379.7, 154.7 388.0, 155.0 398.0 C 155.3 408.0, 157.4 423.5, 158.0 432.0 C 158.6 440.5, 159.2 443.9, 158.4 448.9 C 157.5 453.9, 154.2 458.3, 153.0 462.0 C 151.9 465.6, 151.6 469.0, 151.4 470.6 C 151.2 472.2, 151.6 471.4, 151.9 471.6 C 152.1 471.8, 149.3 472.0, 152.8 472.0 C 156.3 472.0, 169.4 472.1, 172.9 471.9 C 176.4 471.6, 174.0 473.9, 173.9 470.4 C 173.7 466.8, 172.0 457.0, 172.1 450.6 C 172.1 444.2, 172.5 440.9, 174.0 432.1 C 175.5 423.4, 180.0 408.0, 181.0 398.0 C 182.0 388.0, 180.4 379.7, 180.0 372.0 C 179.6 364.3, 177.8 362.7, 178.5 352.0 C 179.3 341.3, 183.2 321.7, 184.5 308.0 C 185.7 294.4, 185.8 278.5, 186.0 270.1 C 186.2 261.7, 185.5 260.2, 185.7 257.6 C 185.8 254.9, 186.5 257.0, 187.0 253.9 C 187.6 250.8, 190.1 245.5, 189.0 239.2 C 187.8 232.9, 182.5 222.9, 180.0 216.0 C 177.5 209.1, 174.1 205.1, 174.1 197.8 C 174.1 190.4, 178.5 178.3, 180.0 172.0 C 181.6 165.6, 182.7 161.8, 183.4 159.6 C 184.1 157.4, 183.7 158.9, 184.1 158.8 C 184.5 158.6, 185.3 158.5, 185.7 158.7 C 186.1 159.0, 184.9 146.8, 186.5 160.0 C 188.1 173.3, 193.9 223.0, 195.5 238.0 C 197.1 252.9, 196.1 242.3, 196.0 249.9 C 195.9 257.6, 194.9 276.1, 195.1 284.1 C 195.3 292.0, 196.6 295.1, 197.2 297.9 C 197.8 300.6, 198.2 299.9, 198.6 300.4 C 199.0 301.0, 199.2 301.0, 199.7 301.0 C 200.2 301.0, 200.6 301.8, 201.5 300.3 C 202.4 298.8, 204.2 296.8, 205.4 292.1 C 206.6 287.3, 208.4 279.0, 208.8 272.0 C 209.2 265.0, 208.1 255.7, 208.0 250.1 C 208.0 244.4, 208.5 242.3, 208.5 238.0 C 208.5 233.7, 208.5 230.7, 208.3 224.0 C 208.1 217.4, 207.7 204.4, 207.4 198.1 C 207.1 191.7, 206.8 190.3, 206.3 186.0 C 205.8 181.7, 204.7 176.4, 204.2 172.0 C 203.7 167.7, 204.3 168.0, 203.5 160.0 C 202.7 152.0, 201.2 132.6, 199.5 124.1 C 197.8 115.6, 194.6 111.7, 193.4 109.0 C 192.2 106.3, 193.4 108.2, 192.1 108.0 C 190.9 107.8, 190.0 110.4, 185.9 107.8 C 181.7 105.2, 171.3 94.9, 167.4 92.3 C 163.4 89.6, 163.5 92.2, 162.4 92.0 C 161.4 91.7, 161.8 92.5, 161.2 90.9 C 160.7 89.2, 159.5 84.6, 159.0 82.1 C 158.5 79.5, 157.5 77.9, 158.3 75.6 C 159.0 73.2, 162.0 70.6, 163.5 68.0 C 164.9 65.4, 166.0 62.9, 167.0 60.0 C 168.0 57.0, 169.0 53.4, 169.5 50.1 C 170.0 46.7, 170.3 43.1, 170.0 40.0 C 169.7 37.0, 169.0 34.1, 167.8 31.8 C 166.7 29.5, 164.9 27.6, 162.9 26.0 C 161.0 24.4, 159.2 22.7, 156.0 22.1 C 152.8 21.4, 147.0 21.5, 143.8 22.1 C 140.6 22.8, 139.0 24.4, 137.0 26.1 C 135.0 27.8, 133.1 30.0, 131.9 32.4 C 130.8 34.7, 130.2 37.1, 130.0 40.0 C 129.8 43.0, 130.0 46.8, 130.5 50.2 C 131.0 53.5, 132.0 57.0, 133.0 60.0 C 134.0 62.9, 135.0 65.2, 136.4 67.8 C 137.9 70.4, 141.0 73.3, 141.7 75.7 C 142.5 78.0, 141.5 79.5, 141.0 82.1 C 140.5 84.7, 139.2 89.5, 138.6 91.2 C 138.1 92.8, 138.6 91.8, 137.6 92.0 C 136.6 92.2, 136.6 89.6, 132.6 92.3 C 128.7 94.9, 118.4 105.1, 114.1 107.8 C 109.9 110.5, 109.3 105.7, 107.0 108.4 C 104.7 111.1, 102.3 115.4, 100.5 124.0 C 98.8 132.6, 97.3 152.0, 96.5 160.0 C 95.7 168.0, 96.3 167.7, 95.8 172.0 C 95.3 176.4, 94.2 181.7, 93.7 186.0 C 93.2 190.3, 92.9 191.7, 92.6 198.0 C 92.3 204.3, 91.9 217.3, 91.7 224.0 C 91.5 230.7, 91.5 233.7, 91.5 238.0 C 91.5 242.3, 92.0 244.4, 92.0 250.1 C 91.9 255.7, 90.8 264.9, 91.2 271.9 Z',
			'm' => 'M 84.6 271.9 C 85.1 278.8, 86.9 287.3, 88.2 292.0 C 89.5 296.7, 91.5 298.8, 92.4 300.3 C 93.2 301.8, 92.9 300.8, 93.3 300.9 C 93.7 301.0, 94.2 301.4, 94.8 300.9 C 95.4 300.4, 96.2 300.7, 97.0 297.9 C 97.8 295.1, 99.0 290.3, 99.4 283.9 C 99.8 277.6, 99.3 265.7, 99.2 260.0 C 99.1 254.4, 98.6 253.6, 98.6 249.9 C 98.6 246.2, 97.6 252.8, 99.2 237.9 C 100.8 222.9, 106.6 174.0, 108.4 160.0 C 110.2 146.1, 109.4 155.1, 109.7 154.0 C 110.1 152.8, 110.2 153.3, 110.5 153.1 C 110.8 153.0, 111.2 152.8, 111.5 153.0 C 111.9 153.2, 111.4 146.9, 112.8 154.3 C 114.2 161.8, 119.7 187.4, 119.9 197.7 C 120.1 208.0, 115.2 209.1, 114.0 216.0 C 112.9 222.9, 113.0 233.7, 113.0 239.0 C 113.0 244.2, 114.0 242.1, 114.1 247.2 C 114.2 252.4, 113.3 259.9, 113.5 270.0 C 113.7 280.1, 113.8 294.3, 115.0 308.0 C 116.2 321.7, 119.8 341.3, 120.5 352.0 C 121.2 362.7, 119.4 364.3, 119.0 372.0 C 118.6 379.7, 117.0 388.0, 118.0 398.0 C 119.0 408.0, 123.4 423.1, 125.0 432.0 C 126.5 440.9, 127.6 446.4, 127.3 451.4 C 126.9 456.4, 124.0 458.8, 123.0 462.1 C 122.0 465.3, 121.4 469.1, 121.4 470.7 C 121.4 472.4, 119.4 471.8, 122.8 472.0 C 126.3 472.2, 138.8 472.1, 142.3 472.0 C 145.7 471.9, 143.1 471.8, 143.3 471.6 C 143.6 471.4, 144.0 473.8, 143.8 470.7 C 143.7 467.6, 142.4 459.5, 142.3 453.0 C 142.2 446.6, 142.4 441.1, 143.0 432.0 C 143.6 422.8, 145.7 408.0, 146.0 398.0 C 146.3 388.0, 145.4 379.7, 145.0 372.0 C 144.6 364.3, 142.9 365.1, 143.5 351.9 C 144.1 338.7, 147.5 302.8, 148.4 292.8 C 149.3 282.7, 148.6 292.0, 148.9 291.7 C 149.2 291.5, 149.7 291.3, 150.1 291.3 C 150.4 291.3, 150.8 291.5, 151.1 291.7 C 151.4 292.0, 150.7 282.7, 151.6 292.8 C 152.5 302.8, 155.9 338.7, 156.5 351.9 C 157.1 365.1, 155.4 364.3, 155.0 372.0 C 154.6 379.7, 153.7 388.0, 154.0 398.0 C 154.3 408.0, 156.4 423.2, 157.0 432.0 C 157.6 440.7, 158.3 445.5, 157.6 450.5 C 157.0 455.5, 154.1 458.6, 153.0 462.0 C 152.0 465.3, 151.6 469.0, 151.4 470.6 C 151.2 472.2, 151.6 471.4, 151.9 471.6 C 152.1 471.8, 149.3 472.0, 152.8 472.0 C 156.3 472.0, 169.4 472.1, 172.9 471.9 C 176.4 471.6, 173.9 473.3, 173.9 470.4 C 173.8 467.4, 172.2 460.6, 172.4 454.2 C 172.6 447.9, 173.4 441.5, 175.0 432.1 C 176.6 422.8, 181.0 408.0, 182.0 398.0 C 183.0 388.0, 181.4 379.7, 181.0 372.0 C 180.6 364.3, 178.8 362.7, 179.5 352.0 C 180.2 341.3, 183.8 321.7, 185.0 308.0 C 186.2 294.4, 186.3 280.2, 186.5 270.1 C 186.6 259.9, 185.8 252.4, 185.9 247.2 C 186.0 242.1, 187.0 244.1, 187.0 239.0 C 187.0 233.8, 187.2 223.0, 186.0 216.1 C 184.8 209.2, 180.4 205.1, 180.1 197.7 C 179.7 190.3, 182.8 179.2, 184.0 172.0 C 185.2 164.7, 186.6 157.5, 187.2 154.3 C 187.9 151.2, 187.6 153.4, 188.0 153.2 C 188.3 153.0, 188.8 152.9, 189.2 153.0 C 189.6 153.1, 189.8 152.7, 190.2 153.9 C 190.6 155.0, 190.8 154.5, 191.6 159.8 C 192.3 165.2, 194.2 179.6, 194.9 186.0 C 195.6 192.3, 194.8 189.3, 195.8 198.0 C 196.8 206.7, 199.9 229.5, 200.8 238.1 C 201.7 246.8, 201.4 246.3, 201.4 249.9 C 201.4 253.6, 200.9 254.4, 200.8 260.0 C 200.7 265.7, 200.2 277.6, 200.6 283.9 C 201.0 290.3, 202.4 295.1, 203.0 297.9 C 203.6 300.6, 204.0 299.9, 204.5 300.4 C 204.9 300.9, 205.1 301.0, 205.6 301.0 C 206.1 301.0, 206.6 301.8, 207.6 300.3 C 208.6 298.8, 210.5 296.7, 211.8 292.0 C 213.1 287.3, 214.9 279.0, 215.4 272.0 C 215.9 265.1, 214.6 255.8, 214.6 250.1 C 214.6 244.4, 215.3 246.6, 215.2 237.9 C 215.1 229.3, 214.6 206.7, 214.2 198.1 C 213.9 189.4, 213.6 190.3, 213.1 186.0 C 212.6 181.7, 211.5 176.4, 211.0 172.1 C 210.6 167.7, 211.2 168.0, 210.4 160.0 C 209.6 152.0, 208.2 132.5, 206.5 123.9 C 204.7 115.3, 202.3 111.0, 199.9 108.3 C 197.5 105.7, 193.6 108.2, 192.0 107.8 C 190.3 107.4, 192.3 107.2, 189.8 105.9 C 187.3 104.6, 180.7 102.2, 177.0 99.9 C 173.2 97.7, 169.4 93.6, 167.3 92.2 C 165.2 90.9, 165.0 92.1, 164.3 91.9 C 163.7 91.8, 164.3 93.9, 163.3 91.1 C 162.3 88.3, 158.6 78.8, 158.6 75.0 C 158.6 71.2, 162.1 70.5, 163.5 68.0 C 164.9 65.5, 166.0 63.0, 167.0 60.0 C 168.0 56.9, 169.0 53.3, 169.5 49.9 C 170.0 46.6, 170.3 43.0, 170.0 40.0 C 169.7 36.9, 168.9 34.0, 167.8 31.7 C 166.6 29.4, 164.9 27.6, 162.9 26.0 C 161.0 24.4, 159.2 22.7, 156.0 22.1 C 152.8 21.4, 147.0 21.5, 143.8 22.1 C 140.6 22.8, 139.0 24.4, 137.0 26.1 C 135.0 27.8, 133.1 30.0, 131.9 32.4 C 130.8 34.7, 130.2 37.1, 130.0 40.0 C 129.8 43.0, 130.0 46.8, 130.5 50.2 C 131.0 53.5, 132.1 57.1, 133.1 60.1 C 134.0 63.1, 135.1 65.5, 136.5 68.0 C 137.9 70.5, 141.4 71.2, 141.4 75.1 C 141.4 79.0, 137.6 88.5, 136.6 91.3 C 135.6 94.1, 136.3 91.8, 135.7 91.9 C 135.0 92.1, 134.8 90.9, 132.7 92.2 C 130.6 93.6, 126.8 97.7, 123.0 99.9 C 119.3 102.2, 112.7 104.6, 110.2 105.9 C 107.7 107.2, 109.7 107.4, 108.0 107.8 C 106.4 108.2, 102.5 105.6, 100.1 108.3 C 97.7 111.0, 95.3 115.4, 93.5 124.0 C 91.8 132.6, 90.4 152.0, 89.6 160.0 C 88.8 168.0, 89.4 167.7, 89.0 172.1 C 88.5 176.4, 87.4 181.7, 86.9 186.0 C 86.4 190.3, 86.2 189.4, 85.8 198.0 C 85.5 206.7, 84.9 229.3, 84.8 237.9 C 84.7 246.6, 85.4 244.4, 85.4 250.1 C 85.4 255.7, 84.1 264.9, 84.6 271.9 Z',
		);

		ob_start();
		echo '<div class="esc-fig">';
		echo '<div class="esc-fig__c">';
		echo self::selector_silueta( $cual ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		printf(
			'<svg viewBox="0 0 300 500" aria-hidden="true" focusable="false">' .
			'<g class="esc-fig__b"><path d="%1$s"/></g>%2$s</svg>',
			esc_attr( $cuerpos[ $cual ] ),
			'<line class="esc-fig__m" x1="212" y1="88" x2="272" y2="88"/><circle class="esc-fig__p" cx="282" cy="88" r="9"/><text class="esc-fig__n" x="282" y="91.5">1</text><line class="esc-fig__m" x1="212" y1="150" x2="272" y2="150"/><circle class="esc-fig__p" cx="282" cy="150" r="9"/><text class="esc-fig__n" x="282" y="153.5">2</text><line class="esc-fig__m" x1="212" y1="198" x2="272" y2="198"/><circle class="esc-fig__p" cx="282" cy="198" r="9"/><text class="esc-fig__n" x="282" y="201.5">3</text><line class="esc-fig__m" x1="212" y1="239" x2="272" y2="239"/><circle class="esc-fig__p" cx="282" cy="239" r="9"/><text class="esc-fig__n" x="282" y="242.5">4</text><line class="esc-fig__m" x1="88" y1="308" x2="58" y2="308"/><circle class="esc-fig__p" cx="48" cy="308" r="9"/><text class="esc-fig__n" x="48" y="311.5">5</text><line class="esc-fig__m" x1="88" y1="398" x2="58" y2="398"/><circle class="esc-fig__p" cx="48" cy="398" r="9"/><text class="esc-fig__n" x="48" y="401.5">6</text><line class="esc-fig__m" x1="212" y1="160" x2="272" y2="160"/><circle class="esc-fig__p" cx="282" cy="160" r="9"/><text class="esc-fig__n" x="282" y="163.5">7</text><line class="esc-fig__m" x1="212" y1="224" x2="272" y2="224"/><circle class="esc-fig__p" cx="282" cy="224" r="9"/><text class="esc-fig__n" x="282" y="227.5">8</text><line class="esc-fig__m" x1="212" y1="250" x2="272" y2="250"/><circle class="esc-fig__p" cx="282" cy="250" r="9"/><text class="esc-fig__n" x="282" y="253.5">9</text><path class="esc-fig__m" d="M14 22 V474 M8 22 H20 M8 474 H20"/><circle class="esc-fig__p" cx="14" cy="260" r="9"/><text class="esc-fig__n" x="14" y="263.5">10</text>'
		);
		echo '</div>';

		printf( '<form method="post" action="%s" class="esc-fig__l">', esc_url( admin_url( 'admin-post.php' ) ) );
		wp_nonce_field( 'malka_crm_medida_punto', '_wpnonce' );
		echo '<input type="hidden" name="action" value="malka_crm_medida_punto" />';

		echo '<ol>';
		$n = 0;

		foreach ( self::puntos() as $clave => $d ) {
			$n++;
			echo self::fila_punto( $clave, $d, $tengo, (string) $n ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '</ol>';

		/*
		 * Los pliegues van en su propia lista y sin número en el dibujo:
		 * son otra técnica —cáliper, milímetros— y meterle siete números
		 * más a la figura la dejaría ilegible.
		 */
		printf( '<h4 class="esc-fig__h">%s</h4>', esc_html__( 'Pliegues, con cáliper', 'malka-crm' ) );
		printf(
			'<p class="esc-hint">%s</p>',
			esc_html__( 'Con cáliper, en milímetros.', 'malka-crm' )
		);
		echo '<ol class="esc-fig__pl">';

		foreach ( self::pliegues() as $clave => $d ) {
			echo self::fila_punto( $clave, $d, $tengo, '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '</ol>';

		printf( '<h4 class="esc-fig__h">%s</h4>', esc_html__( 'Lo que dice tu balanza', 'malka-crm' ) );
		printf(
			'<p class="esc-hint">%s</p>',
			esc_html__( 'Copiados de la pantalla de tu balanza.', 'malka-crm' )
		);
		echo '<ol class="esc-fig__pl">';

		foreach ( self::balanza() as $clave => $d ) {
			echo self::fila_punto( $clave, $d, $tengo, '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '</ol></form></div>';

		return ob_get_clean();
	}

	/**
	 * Una fila de la lista: la medida, cómo se toma, y el botón.
	 *
	 * El cómo se toma aparece al pasar el mouse o al llegar con el
	 * teclado, pero está SIEMPRE en el HTML, no se arma con JavaScript:
	 * así lo lee también quien usa lector de pantalla, que es justo
	 * quien más necesita que se lo cuenten.
	 *
	 * @param string   $clave  Cuál.
	 * @param array    $d      nombre, unidad, cómo se toma.
	 * @param string[] $tengo  Las que ya mide.
	 * @param string   $numero El del dibujo, o '' si no tiene.
	 * @return string
	 */
	private static function fila_punto( $clave, $d, $tengo, $numero ) {
		$ya = in_array( $clave, $tengo, true );

		return sprintf(
			'<li class="esc-fig__i%1$s" tabindex="0">%2$s<span class="esc-fig__q">%3$s<em>%4$s</em></span>' .
			'<span class="esc-fig__como">%5$s</span>' .
			'<button type="submit" class="esc-mini" name="punto" value="%6$s" aria-label="%8$s">%7$s</button></li>',
			$ya ? ' is-ya' : '',
			'' === $numero ? '<i class="esc-fig__sin" aria-hidden="true"></i>' : '<i>' . esc_html( $numero ) . '</i>',
			esc_html( $d[0] ),
			esc_html( $d[1] ),
			esc_html( $d[2] ),
			esc_attr( $clave ),
			$ya ? esc_html__( 'Quitar', 'malka-crm' ) : esc_html__( 'Agregar', 'malka-crm' ),
			esc_attr(
				$ya
					/* translators: la medida */
					? sprintf( __( 'Dejar de medir %s', 'malka-crm' ), $d[0] )
					/* translators: la medida */
					: sprintf( __( 'Empezar a medir %s', 'malka-crm' ), $d[0] )
			)
		);
	}

	/**
	 * Elegir qué silueta se dibuja.
	 *
	 * @param string $cual La actual.
	 * @return string
	 */
	private static function selector_silueta( $cual ) {
		ob_start();
		printf( '<form method="post" action="%s" class="esc-fig__sel">', esc_url( admin_url( 'admin-post.php' ) ) );
		wp_nonce_field( 'malka_crm_silueta', '_wpnonce' );
		echo '<input type="hidden" name="action" value="malka_crm_silueta" />';

		foreach ( array( 'f' => __( 'Mujer', 'malka-crm' ), 'm' => __( 'Hombre', 'malka-crm' ) ) as $k => $rotulo ) {
			printf(
				'<button type="submit" name="silueta" value="%1$s"%2$s>%3$s</button>',
				esc_attr( $k ),
				$k === $cual ? ' class="is-on" aria-pressed="true"' : ' aria-pressed="false"',
				esc_html( $rotulo )
			);
		}

		echo '</form>';

		return ob_get_clean();
	}

	/**
	 * El formulario para anotar una medición.
	 *
	 * @param array[] $tipos Qué se mide.
	 * @return string
	 */
	private static function form_medir( $tipos ) {
		ob_start();
		printf( '<form class="esc-med__n esc-med__anotar" method="post" action="%s">', esc_url( admin_url( 'admin-post.php' ) ) );
		wp_nonce_field( 'malka_crm_medida_anotar', '_wpnonce' );
		echo '<input type="hidden" name="action" value="malka_crm_medida_anotar" />';

		printf(
			'<label><span>%1$s</span><input type="date" name="fecha" value="%2$s" max="%2$s" /></label>',
			esc_html__( 'Cuándo', 'malka-crm' ),
			esc_attr( current_time( 'Y-m-d' ) )
		);

		foreach ( $tipos as $t ) {
			printf(
				'<label><span>%1$s</span><input type="text" inputmode="decimal" name="v[%2$s]" placeholder="%3$s" /></label>',
				esc_html( $t['nombre'] . ( $t['unidad'] ? ' (' . $t['unidad'] . ')' : '' ) ),
				esc_attr( $t['clave'] ),
				esc_attr__( '—', 'malka-crm' )
			);
		}

		printf( '<button type="submit" class="esc-btn esc-btn--primary">%s</button>', esc_html__( 'Anotar', 'malka-crm' ) );
		echo '</form>';

		return ob_get_clean();
	}

	/**
	 * La línea de una medida en el tiempo.
	 *
	 * Sin eje con cero forzado: lo que interesa es el movimiento, y un peso
	 * dibujado desde cero es una línea plana que no dice nada. Los dos
	 * extremos van escritos para que la escala no engañe.
	 *
	 * @param array   $t     El tipo.
	 * @param array[] $serie fecha, valor.
	 * @return string
	 */
	private static function linea( $t, $serie ) {
		$vals = wp_list_pluck( $serie, 'valor' );
		$min  = min( $vals );
		$max  = max( $vals );
		$alto = 90;
		$ancho = 600;

		// Todo igual: una raya al medio, no una división por cero.
		$rango = ( $max - $min ) > 0 ? ( $max - $min ) : 1;
		$pasos = count( $serie ) > 1 ? count( $serie ) - 1 : 1;

		$puntos = array();

		foreach ( $serie as $i => $s ) {
			$x = ( $i / $pasos ) * $ancho;
			$y = $alto - ( ( $s['valor'] - $min ) / $rango ) * ( $alto - 12 ) - 6;

			$puntos[] = round( $x, 1 ) . ',' . round( $y, 1 );
		}

		$ult   = end( $serie );
		$prim  = reset( $serie );
		$dec   = isset( $t['dec'] ) ? (int) $t['dec'] : 1;
		$marca = function ( $v ) use ( $t, $dec ) {
			return number_format_i18n( (float) $v, $dec ) . ( $t['unidad'] ? ' ' . $t['unidad'] : '' );
		};

		/*
		 * La meta que ella puso, si puso una. Entra en la escala del
		 * dibujo: si queda fuera del rango de lo medido, el gráfico se
		 * estira para que la raya se vea; si no, la raya quedaría en el
		 * borde o fuera y no serviría de referencia.
		 */
		$meta = isset( $t['meta'] ) ? (float) $t['meta'] : null;

		if ( null !== $meta ) {
			$min = min( $min, $meta );
			$max = max( $max, $meta );
			// Recalcular con la meta adentro, antes de ubicar los puntos.
			$rango  = ( $max - $min ) > 0 ? ( $max - $min ) : 1;
			$puntos = array();

			foreach ( $serie as $i => $s ) {
				$x = ( $i / $pasos ) * $ancho;
				$y = $alto - ( ( $s['valor'] - $min ) / $rango ) * ( $alto - 12 ) - 6;

				$puntos[] = round( $x, 1 ) . ',' . round( $y, 1 );
			}
		}

		ob_start();
		echo '<div class="esc-med__g">';
		printf(
			'<div class="esc-med__gh"><b>%1$s</b><span>%2$s</span></div>',
			esc_html( $t['nombre'] ),
			esc_html(
				sprintf(
					/* translators: 1: valor más reciente, 2: fecha */
					__( 'Último: %1$s · %2$s', 'malka-crm' ),
					$marca( $ult['valor'] ),
					date_i18n( 'j M Y', strtotime( $ult['fecha'] ) )
				)
			)
		);

		// La raya de la meta, punteada, por debajo de la línea de datos.
		$raya = '';

		if ( null !== $meta ) {
			$ym = $alto - ( ( $meta - $min ) / $rango ) * ( $alto - 12 ) - 6;

			$raya = sprintf(
				'<line x1="0" y1="%1$s" x2="%2$d" y2="%1$s" stroke="currentColor" stroke-width="1" ' .
				'stroke-dasharray="4 4" opacity=".45" vector-effect="non-scaling-stroke" />',
				esc_attr( round( $ym, 1 ) ),
				(int) $ancho
			);
		}

		printf(
			'<svg viewBox="0 0 %1$d %2$d" preserveAspectRatio="none" role="img" aria-label="%3$s">%5$s' .
			'<polyline points="%4$s" fill="none" stroke="currentColor" stroke-width="2" ' .
			'stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke" /></svg>',
			(int) $ancho,
			(int) $alto,
			esc_attr(
				sprintf(
					/* translators: 1: qué, 2: cuántas mediciones, 3: desde, 4: hasta, 5: la meta */
					__( '%1$s: %2$d mediciones, de %3$s a %4$s%5$s', 'malka-crm' ),
					$t['nombre'],
					count( $serie ),
					$marca( $prim['valor'] ),
					$marca( $ult['valor'] ),
					null === $meta
						? ''
						/* translators: la meta */
						: '. ' . sprintf( __( 'Tu meta: %s', 'malka-crm' ), $marca( $meta ) )
				)
			),
			esc_attr( implode( ' ', $puntos ) ),
			$raya // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);

		printf(
			'<div class="esc-med__ge"><span>%1$s</span><span>%2$s</span></div>',
			esc_html( $marca( $min ) ),
			esc_html( $marca( $max ) )
		);

		/*
		 * La distancia a la meta, dicha y nada más. Sin barra de progreso
		 * ni porcentaje cumplido: la meta es de ella y el panel sólo
		 * resta. Tampoco dice «te falta poco» ni «vas lejos» — eso ya
		 * sería opinar.
		 */
		if ( null !== $meta ) {
			$falta = round( abs( $ult['valor'] - $meta ), 2 );

			printf(
				'<p class="esc-med__meta">%s</p>',
				esc_html(
					$falta < 0.005
						/* translators: la meta */
						? sprintf( __( 'Tu meta: %s. Estás ahí.', 'malka-crm' ), $marca( $meta ) )
						: sprintf(
							/* translators: 1: la meta, 2: la diferencia */
							__( 'Tu meta: %1$s · %2$s de diferencia', 'malka-crm' ),
							$marca( $meta ),
							$marca( $falta )
						)
				)
			);
		}

		echo '</div>';

		return ob_get_clean();
	}

	/**
	 * La tabla con lo anotado.
	 *
	 * @param array[] $tipos   Las columnas.
	 * @param array[] $medidas Las filas.
	 * @return string
	 */
	private static function tabla_medidas( $tipos, $medidas ) {
		ob_start();
		echo '<div class="esc-med__tw"><table class="esc-med__t"><thead><tr>';
		printf( '<th>%s</th>', esc_html__( 'Cuándo', 'malka-crm' ) );

		foreach ( $tipos as $t ) {
			printf(
				'<th>%1$s%2$s</th>',
				esc_html( $t['nombre'] ),
				$t['unidad'] ? '<em>' . esc_html( $t['unidad'] ) . '</em>' : ''
			);
		}

		printf( '<th><span class="screen-reader-text">%s</span></th>', esc_html__( 'Corregir', 'malka-crm' ) );
		echo '</tr></thead><tbody>';

		foreach ( $medidas as $m ) {
			/*
			 * Cada fila es un formulario: se corrige ahí mismo, sin
			 * abrir otra pantalla. Un número mal copiado de la balanza
			 * se arregla donde se ve que está mal.
			 */
			printf(
				'<tr><td><form method="post" action="%1$s" id="esc-med-f%2$d">%3$s' .
				'<input type="hidden" name="action" value="malka_crm_medida_editar" />' .
				'<input type="hidden" name="id" value="%2$d" />' .
				'<input type="date" name="fecha" value="%4$s" max="%5$s" aria-label="%6$s" /></form></td>',
				esc_url( admin_url( 'admin-post.php' ) ),
				(int) $m['id'],
				wp_nonce_field( 'malka_crm_medida_editar', '_wpnonce', true, false ),
				esc_attr( $m['fecha'] ),
				esc_attr( current_time( 'Y-m-d' ) ),
				esc_attr__( 'Cuándo se tomó', 'malka-crm' )
			);

			foreach ( $tipos as $t ) {
				$v = isset( $m['valores'][ $t['clave'] ] ) ? $m['valores'][ $t['clave'] ] : '';

				printf(
					'<td><input type="text" inputmode="decimal" form="esc-med-f%1$d" name="v[%2$s]" value="%3$s" placeholder="—" aria-label="%4$s" /></td>',
					(int) $m['id'],
					esc_attr( $t['clave'] ),
					esc_attr( '' === $v ? '' : number_format_i18n( (float) $v, isset( $t['dec'] ) ? (int) $t['dec'] : 1 ) ),
					esc_attr(
						sprintf(
							/* translators: 1: la medida, 2: la fecha */
							__( '%1$s del %2$s', 'malka-crm' ),
							$t['nombre'],
							date_i18n( 'j M Y', strtotime( $m['fecha'] ) )
						)
					)
				);
			}

			printf(
				'<td class="esc-med__acc">' .
				'<button type="submit" form="esc-med-f%1$d" class="esc-mini">%2$s</button>' .
				'<form method="post" action="%3$s">%4$s' .
				'<input type="hidden" name="action" value="malka_crm_medida_borrar" />' .
				'<input type="hidden" name="id" value="%1$d" />' .
				'<button type="submit" class="esc-mini" aria-label="%5$s">%6$s</button></form></td></tr>',
				(int) $m['id'],
				esc_html__( 'Guardar', 'malka-crm' ),
				esc_url( admin_url( 'admin-post.php' ) ),
				wp_nonce_field( 'malka_crm_medida_borrar', '_wpnonce', true, false ),
				esc_attr__( 'Borrar este registro', 'malka-crm' ),
				esc_html__( 'Borrar', 'malka-crm' )
			);
		}

		echo '</tbody></table></div>';
		printf(
			'<p class="esc-hint esc-med__p">%s</p>',
			esc_html__( 'Corrige cualquier número y guarda esa fila. Vaciar una celda saca ese dato; vaciar la fila la borra.', 'malka-crm' )
		);

		return ob_get_clean();
	}

	/** Vuelve a la pantalla de donde se venía. */
	private static function volver( $vista ) {
		wp_safe_redirect( Malka_CRM_Dashboard::view_url( $vista ) );
		exit;
	}

	public static function handle_habito_nuevo() {
		check_admin_referer( 'malka_crm_habito_nuevo' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::habito_nuevo( isset( $_POST['nombre'] ) ? wp_unslash( $_POST['nombre'] ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		self::volver( 'habitos' );
	}

	public static function handle_habito_borrar() {
		check_admin_referer( 'malka_crm_habito_borrar' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::habito_borrar( isset( $_POST['id'] ) ? (int) $_POST['id'] : 0 );
		self::volver( 'habitos' );
	}

	public static function handle_medida_anotar() {
		check_admin_referer( 'malka_crm_medida_anotar' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::medir(
			isset( $_POST['v'] ) ? (array) wp_unslash( $_POST['v'] ) : array(), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			isset( $_POST['fecha'] ) ? wp_unslash( $_POST['fecha'] ) : '' // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		);
		self::volver( 'cuerpo' );
	}

	public static function handle_medida_borrar() {
		check_admin_referer( 'malka_crm_medida_borrar' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::medida_borrar( isset( $_POST['id'] ) ? (int) $_POST['id'] : 0 );
		self::volver( 'cuerpo' );
	}

	public static function handle_medida_tipo() {
		check_admin_referer( 'malka_crm_medida_tipo' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::tipo_nuevo(
			isset( $_POST['nombre'] ) ? wp_unslash( $_POST['nombre'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			isset( $_POST['unidad'] ) ? wp_unslash( $_POST['unidad'] ) : '' // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		);
		self::volver( 'cuerpo' );
	}

	public static function handle_medida_meta() {
		check_admin_referer( 'malka_crm_medida_meta' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		$m = isset( $_POST['m'] ) ? (array) wp_unslash( $_POST['m'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		foreach ( $m as $clave => $valor ) {
			self::meta( $clave, sanitize_text_field( (string) $valor ) );
		}

		self::volver( 'cuerpo' );
	}

	public static function handle_medida_punto() {
		check_admin_referer( 'malka_crm_medida_punto' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::agregar_punto( isset( $_POST['punto'] ) ? sanitize_key( wp_unslash( $_POST['punto'] ) ) : '' );
		self::volver( 'cuerpo' );
	}

	public static function handle_silueta() {
		check_admin_referer( 'malka_crm_silueta' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::poner_silueta( isset( $_POST['silueta'] ) ? sanitize_key( wp_unslash( $_POST['silueta'] ) ) : '' );
		self::volver( 'cuerpo' );
	}

	public static function handle_medida_editar() {
		check_admin_referer( 'malka_crm_medida_editar' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No puedes hacer eso.', 'malka-crm' ) );
		}

		self::editar(
			isset( $_POST['id'] ) ? (int) $_POST['id'] : 0,
			isset( $_POST['v'] ) ? (array) wp_unslash( $_POST['v'] ) : array(), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			isset( $_POST['fecha'] ) ? wp_unslash( $_POST['fecha'] ) : '' // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		);
		self::volver( 'cuerpo' );
	}

	/** Marcar o desmarcar un hábito, sin recargar. */
	public static function ajax_marcar() {
		check_ajax_referer( 'malka_crm_inicio', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'No puedes hacer eso.', 'malka-crm' ) ), 403 );
		}

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$si = ! empty( $_POST['si'] );

		// El día que se está mirando: puede ser uno de atrás, para marcar
		// lo que se olvidó o desmarcar lo que se marcó mal.
		$dia = self::dia_valido( isset( $_POST['dia'] ) ? sanitize_text_field( wp_unslash( $_POST['dia'] ) ) : '' );

		if ( ! self::marcar( $id, $dia, $si ) ) {
			wp_send_json_error( array( 'message' => __( 'Ese hábito ya no está.', 'malka-crm' ) ), 404 );
		}

		// Se devuelve lo que quedó guardado, no lo que se pidió.
		$d      = self::datos();
		$hechos = isset( $d['hechos'][ $id ] ) ? $d['hechos'][ $id ] : array();
		$hoy    = current_time( 'Y-m-d' );

		$racha = self::racha( $hechos, $hoy );
		$total = count( array_filter( $hechos ) );

		wp_send_json_success(
			array(
				'hoy'   => ! empty( $hechos[ $dia ] ),
				'racha' => $racha,
				// Ya redactada: los plurales son del servidor.
				'dice'  => self::racha_dicha( $racha, $total ),
				// Para que la tira de cuatro semanas se pinte sola: hoy es
				// el último punto, un día de atrás es otro.
				'atras' => (int) round( ( strtotime( $hoy ) - strtotime( $dia ) ) / DAY_IN_SECONDS ),
			)
		);
	}
}
