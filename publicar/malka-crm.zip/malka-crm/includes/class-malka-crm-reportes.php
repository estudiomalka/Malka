<?php
/**
 * Reportes: un botón para decir «esto está mal» sin salir de donde estás.
 *
 * Por qué existe. Ir contando los errores de a uno, por chat, obliga a
 * acordarse de dónde estaba el problema, a describir la pantalla y a
 * escribir cuando ya se perdió el hilo de lo que se estaba haciendo. Casi
 * siempre se cuentan menos cosas de las que molestan.
 *
 * Así que el reporte se toma en el momento: un ⚑ fijo en cada pantalla,
 * tres botones para decir de qué se trata, una línea de texto y listo. La
 * pantalla, la fecha, la versión del plugin y el ancho de la ventana los
 * pone el panel, que para eso los sabe. El ancho importa más de lo que
 * parece: la mitad de los «se ve horrible» son de ancho, no de diseño.
 *
 * Lo que NO hace: mandar nada a ninguna parte. Los reportes se quedan en
 * este sitio. En Configuración queda la lista en texto plano para copiar
 * y pegar de una vez. Mandarlos solos a GitHub sería más cómodo pero
 * obliga a darle permiso de escritura a la llave, y eso ya costó bastante
 * la primera vez.
 *
 * @package Malka_CRM
 */

defined( 'ABSPATH' ) || exit;

class Malka_CRM_Reportes {

	/** Dónde se guardan. */
	const OPCION = 'malka_crm_reportes';

	/** Cuántos se conservan. */
	const TOPE = 300;

	/** Largo máximo del texto de un reporte. */
	const LARGO = 1000;

	public static function init() {
		add_action( 'wp_ajax_malka_crm_reporte_nuevo', array( __CLASS__, 'ajax_nuevo' ) );
		add_action( 'admin_post_malka_crm_reporte_borrar', array( __CLASS__, 'handle_borrar' ) );
		add_action( 'admin_post_malka_crm_reporte_estado', array( __CLASS__, 'handle_estado' ) );
		add_action( 'admin_post_malka_crm_reportes_enviados', array( __CLASS__, 'handle_enviados' ) );
	}

	/* ──────────────────────────────  Los datos  ───────────────────────── */

	/**
	 * Los tres tipos de reporte, con el nombre que ella usaría.
	 *
	 * Son tres y no dos porque «falta algo» no es un error: es una idea, y
	 * mezclarla con las fallas hace que las fallas se vean más de las que
	 * son.
	 *
	 * @return array clave => array( nombre corto, rótulo para el texto )
	 */
	public static function tipos() {
		return array(
			'falla' => array( __( 'No funciona', 'malka-crm' ), 'NO FUNCIONA' ),
			'gusto' => array( __( 'No me gusta', 'malka-crm' ), 'NO ME GUSTA' ),
			'falta' => array( __( 'Falta algo', 'malka-crm' ), 'FALTA ALGO' ),
		);
	}

	/**
	 * Todos los reportes, el más nuevo primero.
	 *
	 * @return array
	 */
	public static function todos() {
		$l = get_option( self::OPCION, array() );

		return is_array( $l ) ? array_values( array_filter( $l, 'is_array' ) ) : array();
	}

	/**
	 * Guardar la lista, recortada al tope.
	 *
	 * Si sobra, se van primero los que ya se enviaron: son los que menos
	 * falta hacen.
	 *
	 * @param array $lista Reportes.
	 */
	private static function guardar( array $lista ) {
		if ( count( $lista ) > self::TOPE ) {
			$pend = array();
			$env  = array();

			foreach ( $lista as $r ) {
				if ( empty( $r['enviado'] ) ) {
					$pend[] = $r;
				} else {
					$env[] = $r;
				}
			}

			$lista = array_slice( array_merge( $pend, $env ), 0, self::TOPE );
		}

		update_option( self::OPCION, array_values( $lista ), false );
	}

	/**
	 * Los que todavía no se han pasado.
	 *
	 * @return array
	 */
	public static function pendientes() {
		return array_values(
			array_filter(
				self::todos(),
				function ( $r ) {
					return empty( $r['enviado'] );
				}
			)
		);
	}

	/**
	 * Los que ya se pasaron.
	 *
	 * @return array
	 */
	public static function enviados() {
		return array_values(
			array_filter(
				self::todos(),
				function ( $r ) {
					return ! empty( $r['enviado'] );
				}
			)
		);
	}

	/**
	 * Anotar un reporte.
	 *
	 * @param string $vista Pantalla donde estaba. Se valida contra las vistas que existen.
	 * @param string $tipo  falla, gusto o falta.
	 * @param string $texto Lo que pasa.
	 * @param int    $ancho Ancho de la ventana, en px.
	 * @return array|false El reporte guardado, o false si no había texto.
	 */
	public static function anotar( $vista, $tipo, $texto, $ancho = 0 ) {
		$texto = trim( (string) $texto );

		if ( '' === $texto ) {
			return false;
		}

		$tipos = self::tipos();
		$tipo  = isset( $tipos[ $tipo ] ) ? $tipo : 'falla';

		/*
		 * La vista la manda el navegador, así que no se cree: tiene que ser
		 * una de las que el panel dibuja. Cualquier otra cosa queda como
		 * «otra», que es honesto y no inventa una pantalla que no existe.
		 */
		$vista = sanitize_key( (string) $vista );
		if ( ! class_exists( 'Malka_CRM_Dashboard' ) || ! isset( Malka_CRM_Dashboard::views()[ $vista ] ) ) {
			$vista = '';
		}

		$ancho = absint( $ancho );
		if ( $ancho < 200 || $ancho > 6000 ) {
			$ancho = 0;
		}

		$r = array(
			'id'      => uniqid( 'r', true ),
			'fecha'   => current_time( 'Y-m-d H:i:s' ),
			'vista'   => $vista,
			'tipo'    => $tipo,
			'texto'   => mb_substr( sanitize_textarea_field( $texto ), 0, self::LARGO ),
			'version' => defined( 'MALKA_CRM_VERSION' ) ? MALKA_CRM_VERSION : '',
			'ancho'   => $ancho,
			'enviado' => '',
		);

		$lista = self::todos();
		array_unshift( $lista, $r );
		self::guardar( $lista );

		return $r;
	}

	/**
	 * Borrar un reporte.
	 *
	 * @param string $id Id del reporte.
	 * @return bool Si había algo que borrar.
	 */
	public static function borrar( $id ) {
		$id    = (string) $id;
		$lista = self::todos();
		$queda = array_values(
			array_filter(
				$lista,
				function ( $r ) use ( $id ) {
					return ! isset( $r['id'] ) || (string) $r['id'] !== $id;
				}
			)
		);

		if ( count( $queda ) === count( $lista ) ) {
			return false;
		}

		self::guardar( $queda );

		return true;
	}

	/**
	 * Marcar un reporte como enviado, o devolverlo a pendientes.
	 *
	 * @param string $id      Id del reporte.
	 * @param bool   $enviado Si queda enviado.
	 * @return bool Si se encontró.
	 */
	public static function estado( $id, $enviado ) {
		$id    = (string) $id;
		$lista = self::todos();
		$hubo  = false;

		foreach ( $lista as $i => $r ) {
			if ( isset( $r['id'] ) && (string) $r['id'] === $id ) {
				$lista[ $i ]['enviado'] = $enviado ? current_time( 'Y-m-d H:i:s' ) : '';
				$hubo                   = true;
			}
		}

		if ( $hubo ) {
			self::guardar( $lista );
		}

		return $hubo;
	}

	/**
	 * Marcar todos los pendientes como enviados.
	 *
	 * @return int Cuántos se marcaron.
	 */
	public static function marcar_enviados() {
		$lista = self::todos();
		$n     = 0;
		$ahora = current_time( 'Y-m-d H:i:s' );

		foreach ( $lista as $i => $r ) {
			if ( empty( $r['enviado'] ) ) {
				$lista[ $i ]['enviado'] = $ahora;
				++$n;
			}
		}

		if ( $n ) {
			self::guardar( $lista );
		}

		return $n;
	}

	/* ────────────────────────────  El texto plano  ─────────────────────── */

	/**
	 * Cómo se llama la pantalla donde se tomó el reporte.
	 *
	 * @param string $vista Clave de la vista.
	 * @return string
	 */
	private static function nombre_vista( $vista ) {
		if ( '' === (string) $vista ) {
			return __( 'sin pantalla', 'malka-crm' );
		}

		$v = class_exists( 'Malka_CRM_Dashboard' ) ? Malka_CRM_Dashboard::views() : array();

		return isset( $v[ $vista ] ) ? $v[ $vista ] : $vista;
	}

	/**
	 * Los reportes en texto plano, para copiar y pegar de una vez.
	 *
	 * Lleva la versión instalada arriba, y la de cada reporte sólo cuando es
	 * distinta: así se ve de una que algo se reportó con una versión vieja y
	 * puede que ya esté arreglado, sin repetir el mismo número en cada
	 * línea.
	 *
	 * @param array|null $lista Qué reportes. Por defecto, los pendientes.
	 * @return string Vacío si no hay ninguno.
	 */
	public static function texto_plano( $lista = null ) {
		$lista = null === $lista ? self::pendientes() : array_values( $lista );

		if ( ! $lista ) {
			return '';
		}

		$ahora = defined( 'MALKA_CRM_VERSION' ) ? MALKA_CRM_VERSION : '';
		$tipos = self::tipos();

		$out = sprintf(
			/* translators: 1: versión del plugin, 2: cuántos reportes */
			_n( 'Malka CRM %1$s — %2$d reporte', 'Malka CRM %1$s — %2$d reportes', count( $lista ), 'malka-crm' ),
			$ahora,
			count( $lista )
		) . "\n";

		if ( class_exists( 'Malka_CRM_Dashboard' ) ) {
			$out .= Malka_CRM_Dashboard::view_url( 'inicio' ) . "\n";
		}

		$i = 0;
		foreach ( $lista as $r ) {
			++$i;
			$tipo  = isset( $r['tipo'], $tipos[ $r['tipo'] ] ) ? $tipos[ $r['tipo'] ][1] : 'NO FUNCIONA';
			$parts = array(
				$tipo,
				self::nombre_vista( isset( $r['vista'] ) ? $r['vista'] : '' ),
				isset( $r['fecha'] ) ? mysql2date( 'd-m H:i', $r['fecha'] ) : '',
			);

			$ver = isset( $r['version'] ) ? (string) $r['version'] : '';
			if ( '' !== $ver && $ver !== $ahora ) {
				/* translators: versión del plugin con la que se tomó el reporte */
				$parts[] = sprintf( __( 'reportado en la %s', 'malka-crm' ), $ver );
			}

			if ( ! empty( $r['ancho'] ) ) {
				$parts[] = (int) $r['ancho'] . 'px';
			}

			$out .= "\n" . $i . ') ' . implode( ' · ', array_filter( $parts ) ) . "\n";
			$out .= '   ' . str_replace( "\n", "\n   ", trim( (string) ( isset( $r['texto'] ) ? $r['texto'] : '' ) ) ) . "\n";
		}

		return $out;
	}

	/* ─────────────────────────────  El botón ⚑  ────────────────────────── */

	/**
	 * El ⚑ fijo y su formulario, para pegarlo en cada pantalla.
	 *
	 * @param string $vista Pantalla en la que está.
	 * @return string
	 */
	public static function burbuja( $vista = '' ) {
		if ( ! class_exists( 'Malka_CRM_Helpers' ) || ! Malka_CRM_Helpers::current_user_is_manager() ) {
			return '';
		}

		$n    = count( self::pendientes() );
		$cfg  = class_exists( 'Malka_CRM_Dashboard' ) ? Malka_CRM_Dashboard::view_url( 'configuracion' ) : '';
		$tips = self::tipos();

		ob_start();

		printf(
			'<div class="esc-rep" id="esc-rep" data-nonce="%1$s" data-vista="%2$s" data-n="%3$d">',
			esc_attr( wp_create_nonce( 'malka_crm_reporte' ) ),
			esc_attr( $vista ),
			(int) $n
		);

		printf(
			'<button type="button" class="esc-rep__b" data-rep-abrir aria-label="%1$s" title="%1$s">' .
			'<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' .
			'<path d="M6 21V4"/><path d="M6 4.5h11l-2 4 2 4H6"/></svg>' .
			'<span class="esc-rep__n" data-rep-cuenta%2$s>%3$d</span></button>',
			esc_attr__( 'Reportar algo de esta pantalla', 'malka-crm' ),
			$n ? '' : ' hidden',
			(int) $n
		);

		printf( '<section class="esc-rep__p" hidden aria-label="%s">', esc_attr__( 'Reportar algo', 'malka-crm' ) );

		printf(
			'<header class="esc-rep__h"><div><b>%1$s</b><small>%2$s</small></div>' .
			'<button type="button" class="esc-rep__x" data-rep-cerrar aria-label="%3$s">&times;</button></header>',
			esc_html__( 'Reportar', 'malka-crm' ),
			esc_html( self::nombre_vista( $vista ) ),
			esc_attr__( 'Cerrar', 'malka-crm' )
		);

		echo '<div class="esc-rep__c">';

		printf( '<div class="esc-rep__t" role="group" aria-label="%s">', esc_attr__( 'Qué pasa', 'malka-crm' ) );
		$primero = true;
		foreach ( $tips as $k => $t ) {
			printf(
				'<button type="button" data-rep-tipo="%1$s" aria-pressed="%2$s"%3$s>%4$s</button>',
				esc_attr( $k ),
				$primero ? 'true' : 'false',
				$primero ? ' class="is-on"' : '',
				esc_html( $t[0] )
			);
			$primero = false;
		}
		echo '</div>';

		printf(
			'<label class="esc-rep__lb" for="esc-rep-txt">%1$s</label>' .
			'<textarea class="esc-rep__i" id="esc-rep-txt" rows="3" maxlength="%2$d" placeholder="%3$s"></textarea>',
			esc_html__( 'Qué pasa', 'malka-crm' ),
			(int) self::LARGO,
			esc_attr__( 'Una línea basta. Si no sabes por qué no te gusta, dilo igual.', 'malka-crm' )
		);

		printf(
			'<div class="esc-rep__f"><small>%1$s</small>' .
			'<button type="button" class="esc-btn esc-btn--primary" data-rep-enviar>%2$s</button></div>',
			esc_html__( 'Queda con la pantalla y la fecha.', 'malka-crm' ),
			esc_html__( 'Guardar', 'malka-crm' )
		);

		printf( '<p class="esc-rep__ok" data-rep-ok role="status" aria-live="polite" hidden></p>' );

		if ( '' !== $cfg ) {
			printf(
				'<a class="esc-rep__ver" href="%1$s">%2$s</a>',
				esc_url( $cfg . '#cfg-reportes' ),
				esc_html__( 'Ver y copiar los guardados', 'malka-crm' )
			);
		}

		echo '</div></section></div>';

		return ob_get_clean();
	}

	/* ───────────────────────  La lista en Configuración  ──────────────── */

	/**
	 * La sección de Configuración: la lista, el texto para copiar y el botón
	 * para marcarlos como enviados.
	 *
	 * El texto va en un cuadro de sólo lectura y además hay un botón que lo
	 * copia. El cuadro está porque el botón depende del navegador y de que la
	 * página vaya por https; seleccionar a mano funciona siempre, y ésta es
	 * justo la pantalla donde no conviene depender de que algo funcione.
	 *
	 * @return string
	 */
	public static function panel() {
		$pend = self::pendientes();
		$env  = self::enviados();
		$tips = self::tipos();

		ob_start();

		echo '<section class="esc-panel" id="cfg-reportes"><div class="esc-ph"><div><h2>' . esc_html__( 'Reportes', 'malka-crm' ) . '</h2>';
		echo '<p>' . esc_html__( 'Lo que anotaste con el ⚑ de cada pantalla. Copia todo de una vez y pégaselo a Claude.', 'malka-crm' ) . '</p></div></div>';

		if ( ! $pend && ! $env ) {
			echo '<p class="esc-hint">' . esc_html__( 'Nada anotado todavía. El ⚑ está abajo a la derecha, en cualquier pantalla.', 'malka-crm' ) . '</p>';
			echo '</section>';

			return ob_get_clean();
		}

		if ( $pend ) {
			printf(
				'<textarea class="esc-rep__tx" id="cfg-rep-tx" rows="%1$d" readonly aria-label="%2$s">%3$s</textarea>',
				(int) min( 18, 3 + count( $pend ) * 3 ),
				esc_attr__( 'Los reportes en texto, para copiar', 'malka-crm' ),
				esc_textarea( self::texto_plano( $pend ) )
			);

			echo '<div class="esc-rep__acc">';

			printf(
				'<button type="button" class="esc-btn" data-rep-copiar="cfg-rep-tx" data-rep-dicho="%1$s">%2$s</button>',
				esc_attr__( 'Copiado', 'malka-crm' ),
				esc_html__( 'Copiar todo', 'malka-crm' )
			);

			printf(
				'<form method="post" action="%1$s">%2$s' .
				'<input type="hidden" name="action" value="malka_crm_reportes_enviados" />' .
				'<input type="hidden" name="malka_volver" value="%3$s" />' .
				'<button type="submit" class="esc-btn esc-btn--ghost">%4$s</button></form>',
				esc_url( admin_url( 'admin-post.php' ) ),
				wp_nonce_field( 'malka_crm_reportes_enviados', '_wpnonce', true, false ),
				esc_attr( class_exists( 'Malka_CRM_Dashboard' ) ? Malka_CRM_Dashboard::view_url( 'configuracion' ) . '#cfg-reportes' : '' ),
				esc_html(
					sprintf(
						/* translators: cuántos reportes */
						_n( 'Marcar %d como enviado', 'Marcar los %d como enviados', count( $pend ), 'malka-crm' ),
						count( $pend )
					)
				)
			);

			echo '</div>';

			echo '<ul class="esc-rep__l">';
			foreach ( $pend as $r ) {
				echo self::fila( $r, $tips ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</ul>';
		} else {
			echo '<p class="esc-hint">' . esc_html__( 'No queda ninguno pendiente.', 'malka-crm' ) . '</p>';
		}

		if ( $env ) {
			printf(
				'<details class="esc-rep__d"><summary>%s</summary>',
				esc_html(
					sprintf(
						/* translators: cuántos reportes */
						_n( '%d ya enviado', '%d ya enviados', count( $env ), 'malka-crm' ),
						count( $env )
					)
				)
			);
			echo '<ul class="esc-rep__l">';
			foreach ( $env as $r ) {
				echo self::fila( $r, $tips ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</ul></details>';
		}

		echo '</section>';

		return ob_get_clean();
	}

	/**
	 * Una fila de la lista.
	 *
	 * @param array $r    El reporte.
	 * @param array $tips Los tipos.
	 * @return string
	 */
	private static function fila( array $r, array $tips ) {
		$id      = isset( $r['id'] ) ? (string) $r['id'] : '';
		$enviado = ! empty( $r['enviado'] );
		$tipo    = isset( $r['tipo'], $tips[ $r['tipo'] ] ) ? $tips[ $r['tipo'] ][0] : $tips['falla'][0];
		$volver  = class_exists( 'Malka_CRM_Dashboard' ) ? Malka_CRM_Dashboard::view_url( 'configuracion' ) . '#cfg-reportes' : '';
		$meta    = array( self::nombre_vista( isset( $r['vista'] ) ? $r['vista'] : '' ) );

		if ( ! empty( $r['fecha'] ) ) {
			$meta[] = mysql2date( 'd-m H:i', $r['fecha'] );
		}

		if ( ! empty( $r['ancho'] ) ) {
			$meta[] = (int) $r['ancho'] . 'px';
		}

		ob_start();

		printf( '<li class="esc-rep__li%s">', $enviado ? ' is-enviado' : '' );
		printf(
			'<span class="esc-rep__tg" data-tipo="%1$s">%2$s</span>',
			esc_attr( isset( $r['tipo'] ) ? $r['tipo'] : 'falla' ),
			esc_html( $tipo )
		);
		echo '<span class="esc-rep__q">';
		printf( '<b>%s</b>', esc_html( (string) ( isset( $r['texto'] ) ? $r['texto'] : '' ) ) );
		printf( '<small>%s</small>', esc_html( implode( ' · ', $meta ) ) );
		echo '</span>';

		echo '<span class="esc-rep__ac">';
		printf(
			'<form method="post" action="%1$s">%2$s' .
			'<input type="hidden" name="action" value="malka_crm_reporte_estado" />' .
			'<input type="hidden" name="id" value="%3$s" />' .
			'<input type="hidden" name="enviado" value="%4$s" />' .
			'<input type="hidden" name="malka_volver" value="%5$s" />' .
			'<button type="submit" class="esc-rep__mini">%6$s</button></form>',
			esc_url( admin_url( 'admin-post.php' ) ),
			wp_nonce_field( 'malka_crm_reporte_estado', '_wpnonce', true, false ),
			esc_attr( $id ),
			$enviado ? '' : '1',
			esc_attr( $volver ),
			esc_html( $enviado ? __( 'Volver a pendiente', 'malka-crm' ) : __( 'Enviado', 'malka-crm' ) )
		);
		printf(
			'<form method="post" action="%1$s">%2$s' .
			'<input type="hidden" name="action" value="malka_crm_reporte_borrar" />' .
			'<input type="hidden" name="id" value="%3$s" />' .
			'<input type="hidden" name="malka_volver" value="%4$s" />' .
			'<button type="submit" class="esc-rep__mini is-x" aria-label="%5$s" title="%5$s">&times;</button></form>',
			esc_url( admin_url( 'admin-post.php' ) ),
			wp_nonce_field( 'malka_crm_reporte_borrar', '_wpnonce', true, false ),
			esc_attr( $id ),
			esc_attr( $volver ),
			esc_attr__( 'Borrar', 'malka-crm' )
		);
		echo '</span></li>';

		return ob_get_clean();
	}

	/* ──────────────────────────────  Entradas  ────────────────────────── */

	/**
	 * Guardar un reporte desde el ⚑.
	 */
	public static function ajax_nuevo() {
		check_ajax_referer( 'malka_crm_reporte', 'nonce' );

		if ( ! class_exists( 'Malka_CRM_Helpers' ) || ! Malka_CRM_Helpers::current_user_is_manager() ) {
			wp_send_json_error( array( 'dice' => __( 'No tienes permiso.', 'malka-crm' ) ), 403 );
		}

		$r = self::anotar(
			isset( $_POST['vista'] ) ? sanitize_key( wp_unslash( $_POST['vista'] ) ) : '',
			isset( $_POST['tipo'] ) ? sanitize_key( wp_unslash( $_POST['tipo'] ) ) : 'falla',
			isset( $_POST['texto'] ) ? wp_unslash( $_POST['texto'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			isset( $_POST['ancho'] ) ? absint( wp_unslash( $_POST['ancho'] ) ) : 0
		);

		if ( ! $r ) {
			wp_send_json_error( array( 'dice' => __( 'Escribe qué pasa.', 'malka-crm' ) ), 400 );
		}

		$n = count( self::pendientes() );

		wp_send_json_success(
			array(
				'n'    => $n,
				'dice' => sprintf(
					/* translators: cuántos reportes pendientes */
					_n( 'Guardado. Llevas %d.', 'Guardado. Llevas %d.', $n, 'malka-crm' ),
					$n
				),
			)
		);
	}

	/**
	 * A dónde volver después de guardar.
	 *
	 * @return string
	 */
	private static function volver() {
		$v = isset( $_POST['malka_volver'] ) ? esc_url_raw( wp_unslash( $_POST['malka_volver'] ) ) : '';

		if ( '' !== $v ) {
			return $v;
		}

		return class_exists( 'Malka_CRM_Dashboard' )
			? Malka_CRM_Dashboard::view_url( 'configuracion' ) . '#cfg-reportes'
			: home_url( '/' );
	}

	/**
	 * Borrar un reporte.
	 */
	public static function handle_borrar() {
		check_admin_referer( 'malka_crm_reporte_borrar' );

		if ( ! class_exists( 'Malka_CRM_Helpers' ) || ! Malka_CRM_Helpers::current_user_is_manager() ) {
			wp_die( esc_html__( 'No tienes permiso.', 'malka-crm' ) );
		}

		self::borrar( isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '' );
		wp_safe_redirect( self::volver() );
		exit;
	}

	/**
	 * Marcar uno como enviado, o devolverlo.
	 */
	public static function handle_estado() {
		check_admin_referer( 'malka_crm_reporte_estado' );

		if ( ! class_exists( 'Malka_CRM_Helpers' ) || ! Malka_CRM_Helpers::current_user_is_manager() ) {
			wp_die( esc_html__( 'No tienes permiso.', 'malka-crm' ) );
		}

		self::estado(
			isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '',
			! empty( $_POST['enviado'] )
		);
		wp_safe_redirect( self::volver() );
		exit;
	}

	/**
	 * Marcar todos los pendientes como enviados.
	 */
	public static function handle_enviados() {
		check_admin_referer( 'malka_crm_reportes_enviados' );

		if ( ! class_exists( 'Malka_CRM_Helpers' ) || ! Malka_CRM_Helpers::current_user_is_manager() ) {
			wp_die( esc_html__( 'No tienes permiso.', 'malka-crm' ) );
		}

		self::marcar_enviados();
		wp_safe_redirect( self::volver() );
		exit;
	}
}
